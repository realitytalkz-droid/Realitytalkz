# RealityWithEdwin — Android-ready project

This is the React + Vite app prepared to be packaged as an Android app with Capacitor. The decorative phone mockup from the AI Studio preview has been removed so the app fills the real device screen.

## Requirements

- Node.js 20.19+ (or a compatible newer LTS release)
- npm
- Android Studio with Android SDK installed (needed to compile an APK)

## Build the web app

```bash
npm install
npm run build
```

## Add Android support (run once)

```bash
npm run cap:add:android
```

## Sync changes and open Android project

```bash
npm run cap:sync
npm run cap:open:android
```

Android Studio can then build an APK using **Build > Build Bundle(s) / APK(s) > Build APK(s)**. For a command-line debug APK, run:

```bash
cd android
./gradlew assembleDebug
```

The debug APK is normally created at `android/app/build/outputs/apk/debug/app-debug.apk`.

## Important notes

- The ZIP is source code, not an installable APK. It must be built first.
- The project currently contains demo/mock content and UI flows. Login, cloud-synced user data, real push notifications, live video hosting, and production AdMob require their own backend/provider configuration and testing before public release.
- Do not put private API keys in frontend source files or commit `.env` files. Use a secure backend for secrets.
- This project is not yet signed for a public Google Play release. A release build, signing key, store listing, privacy policy, and Google Play testing/compliance steps are still required.

## Phone-only workflow

A phone can be used to edit files and run a cloud development environment, but generating a native Android APK still requires a build environment with the Android SDK and Gradle. If using a cloud workspace, make sure it supports Android SDK/Gradle builds and lets you download the resulting APK.

## Build the APK using GitHub Actions (phone-friendly)

This ZIP includes `.github/workflows/build-android-apk.yml`. After uploading the extracted project contents to a GitHub repository on the `main` branch:

1. Open the repository on GitHub.
2. Tap **Actions** and select **Build RealityWithEdwin Android APK**.
3. Tap **Run workflow** if it has not started automatically after your push.
4. Wait for the workflow to finish successfully.
5. Open the completed workflow run and download the **RealityWithEdwin-debug-apk** artifact.
6. Extract the downloaded artifact ZIP; it contains `app-debug.apk`.
7. Tap `app-debug.apk` on your Android phone to install it.

The GitHub Actions workflow builds a debug APK for testing. It is not a Play Store release build.
