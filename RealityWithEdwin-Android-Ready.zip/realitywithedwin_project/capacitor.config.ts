import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.realitywithedwin.app',
  appName: 'RealityWithEdwin',
  webDir: 'dist',
  androidScheme: 'https',
  bundledWebRuntime: false,
};

export default config;
