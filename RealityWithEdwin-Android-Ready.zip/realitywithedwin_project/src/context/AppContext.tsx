import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  NavigationTab, 
  VideoItem, 
  QuoteItem, 
  RelationshipArticle, 
  CommentItem, 
  UserProfile, 
  AppNotification, 
  EntertainmentStory 
} from '../types';
import { 
  INITIAL_VIDEOS, 
  INITIAL_QUOTES, 
  INITIAL_ARTICLES, 
  INITIAL_STORIES, 
  INITIAL_COMMENTS, 
  INITIAL_USER, 
  INITIAL_NOTIFICATIONS 
} from '../data/mockData';

interface AppContextType {
  activeTab: NavigationTab;
  setActiveTab: (tab: NavigationTab) => void;
  user: UserProfile;
  updateUser: (updated: Partial<UserProfile>) => void;
  loginUser: (email: string, name: string) => void;
  logoutUser: () => void;
  toggleVIP: () => void;
  toggleAdmin: () => void;

  videos: VideoItem[];
  addVideo: (video: Omit<VideoItem, 'id' | 'views' | 'likes' | 'uploadedAt'>) => void;
  likeVideo: (videoId: string) => void;
  activeVideo: VideoItem | null;
  setActiveVideo: (video: VideoItem | null) => void;

  quotes: QuoteItem[];
  addQuote: (quote: Omit<QuoteItem, 'id' | 'likes' | 'shares'>) => void;
  likeQuote: (quoteId: string) => void;
  shareQuote: (quoteId: string) => void;

  articles: RelationshipArticle[];
  addArticle: (article: Omit<RelationshipArticle, 'id' | 'likes' | 'publishedAt'>) => void;
  likeArticle: (articleId: string) => void;
  activeArticle: RelationshipArticle | null;
  setActiveArticle: (article: RelationshipArticle | null) => void;

  stories: EntertainmentStory[];
  activeStory: EntertainmentStory | null;
  setActiveStory: (story: EntertainmentStory | null) => void;

  comments: CommentItem[];
  addComment: (contentId: string, text: string) => void;
  deleteComment: (commentId: string) => void;
  toggleCommentApproval: (commentId: string) => void;
  likeComment: (commentId: string) => void;

  savedVideoIds: string[];
  savedQuoteIds: string[];
  savedArticleIds: string[];
  toggleSaveVideo: (videoId: string) => void;
  toggleSaveQuote: (quoteId: string) => void;
  toggleSaveArticle: (articleId: string) => void;

  notifications: AppNotification[];
  unreadNotifCount: number;
  markNotifAsRead: (id: string) => void;
  markAllNotifsAsRead: () => void;
  sendSimulatedPush: (title: string, message: string, type: AppNotification['type']) => void;

  showShareModal: boolean;
  setShowShareModal: (show: boolean) => void;
  shareData: { title: string; text: string; url: string } | null;
  openShareModal: (title: string, text: string, url?: string) => void;

  showDonationModal: boolean;
  setShowDonationModal: (show: boolean) => void;

  showAdminModal: boolean;
  setShowAdminModal: (show: boolean) => void;

  showAdMobBanner: boolean;
  setShowAdMobBanner: (show: boolean) => void;

  isPhoneFrame: boolean;
  setIsPhoneFrame: (val: boolean) => void;

  toastMessage: string | null;
  showToast: (msg: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeTab, setActiveTab] = useState<NavigationTab>('home');

  // Persistence helpers
  const [user, setUser] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('rwe_user');
    return saved ? JSON.parse(saved) : INITIAL_USER;
  });

  const [videos, setVideos] = useState<VideoItem[]>(() => {
    const saved = localStorage.getItem('rwe_videos');
    return saved ? JSON.parse(saved) : INITIAL_VIDEOS;
  });

  const [quotes, setQuotes] = useState<QuoteItem[]>(() => {
    const saved = localStorage.getItem('rwe_quotes');
    return saved ? JSON.parse(saved) : INITIAL_QUOTES;
  });

  const [articles, setArticles] = useState<RelationshipArticle[]>(() => {
    const saved = localStorage.getItem('rwe_articles');
    return saved ? JSON.parse(saved) : INITIAL_ARTICLES;
  });

  const [stories] = useState<EntertainmentStory[]>(INITIAL_STORIES);

  const [comments, setComments] = useState<CommentItem[]>(() => {
    const saved = localStorage.getItem('rwe_comments');
    return saved ? JSON.parse(saved) : INITIAL_COMMENTS;
  });

  const [notifications, setNotifications] = useState<AppNotification[]>(() => {
    const saved = localStorage.getItem('rwe_notifs');
    return saved ? JSON.parse(saved) : INITIAL_NOTIFICATIONS;
  });

  // Modal states
  const [activeVideo, setActiveVideo] = useState<VideoItem | null>(null);
  const [activeArticle, setActiveArticle] = useState<RelationshipArticle | null>(null);
  const [activeStory, setActiveStory] = useState<EntertainmentStory | null>(null);
  const [showShareModal, setShowShareModal] = useState(false);
  const [shareData, setShareData] = useState<{ title: string; text: string; url: string } | null>(null);
  const [showDonationModal, setShowDonationModal] = useState(false);
  const [showAdminModal, setShowAdminModal] = useState(false);
  const [showAdMobBanner, setShowAdMobBanner] = useState(true);
  const [isPhoneFrame, setIsPhoneFrame] = useState(true); // Default to realistic Android mobile container preview
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem('rwe_user', JSON.stringify(user));
  }, [user]);

  useEffect(() => {
    localStorage.setItem('rwe_videos', JSON.stringify(videos));
  }, [videos]);

  useEffect(() => {
    localStorage.setItem('rwe_quotes', JSON.stringify(quotes));
  }, [quotes]);

  useEffect(() => {
    localStorage.setItem('rwe_articles', JSON.stringify(articles));
  }, [articles]);

  useEffect(() => {
    localStorage.setItem('rwe_comments', JSON.stringify(comments));
  }, [comments]);

  useEffect(() => {
    localStorage.setItem('rwe_notifs', JSON.stringify(notifications));
  }, [notifications]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((curr) => (curr === msg ? null : curr));
    }, 3200);
  };

  const updateUser = (updated: Partial<UserProfile>) => {
    setUser((prev) => ({ ...prev, ...updated }));
    showToast('Profile updated successfully');
  };

  const loginUser = (email: string, name: string) => {
    setUser((prev) => ({
      ...prev,
      email,
      name: name || email.split('@')[0],
    }));
    showToast(`Welcome back, ${name || 'Beloved Seeker'}!`);
  };

  const logoutUser = () => {
    setUser({
      ...INITIAL_USER,
      name: 'Guest Visitor',
      email: 'guest@realitywithedwin.com',
      isAdmin: false,
      isVIP: false,
    });
    showToast('Logged out of session');
  };

  const toggleVIP = () => {
    setUser((prev) => {
      const nextVIP = !prev.isVIP;
      showToast(nextVIP ? '⭐ Welcome to RealityWithEdwin VIP Gold Circle!' : 'VIP status deactivated');
      return { ...prev, isVIP: nextVIP };
    });
  };

  const toggleAdmin = () => {
    setUser((prev) => {
      const nextAdmin = !prev.isAdmin;
      showToast(nextAdmin ? '🔑 Admin mode activated' : 'Exited admin mode');
      return { ...prev, isAdmin: nextAdmin };
    });
  };

  // Video Actions
  const addVideo = (newVid: Omit<VideoItem, 'id' | 'views' | 'likes' | 'uploadedAt'>) => {
    const created: VideoItem = {
      ...newVid,
      id: `vid-${Date.now()}`,
      views: 120,
      likes: 15,
      uploadedAt: 'Just now',
      isRecent: true,
    };
    setVideos((prev) => [created, ...prev]);
    showToast('New motivational video published!');
    sendSimulatedPush('New Video Alert!', `Edwin published: "${newVid.title}"`, 'video');
  };

  const likeVideo = (videoId: string) => {
    setVideos((prev) =>
      prev.map((v) => (v.id === videoId ? { ...v, likes: v.likes + 1 } : v))
    );
    showToast('Liked video');
  };

  // Quote Actions
  const addQuote = (newQuote: Omit<QuoteItem, 'id' | 'likes' | 'shares'>) => {
    const created: QuoteItem = {
      ...newQuote,
      id: `quote-${Date.now()}`,
      likes: 8,
      shares: 2,
    };
    setQuotes((prev) => [created, ...prev]);
    showToast('Daily Quote published to community!');
    sendSimulatedPush('Daily Motivation from Edwin', `"${newQuote.text.substring(0, 70)}..."`, 'quote');
  };

  const likeQuote = (quoteId: string) => {
    setQuotes((prev) =>
      prev.map((q) => (q.id === quoteId ? { ...q, likes: q.likes + 1 } : q))
    );
    showToast('Quote saved to favorites');
  };

  const shareQuote = (quoteId: string) => {
    setQuotes((prev) =>
      prev.map((q) => (q.id === quoteId ? { ...q, shares: q.shares + 1 } : q))
    );
  };

  // Article Actions
  const addArticle = (newArt: Omit<RelationshipArticle, 'id' | 'likes' | 'publishedAt'>) => {
    const created: RelationshipArticle = {
      ...newArt,
      id: `art-${Date.now()}`,
      likes: 12,
      publishedAt: 'Just now',
    };
    setArticles((prev) => [created, ...prev]);
    showToast('Relationship article published!');
    sendSimulatedPush('Relationship Wisdom Added', `Read "${newArt.title}" by Edwin`, 'relationship');
  };

  const likeArticle = (artId: string) => {
    setArticles((prev) =>
      prev.map((a) => (a.id === artId ? { ...a, likes: a.likes + 1 } : a))
    );
    showToast('Article liked');
  };

  // Comment Actions
  const addComment = (contentId: string, text: string) => {
    if (!text.trim()) return;
    const newComm: CommentItem = {
      id: `comm-${Date.now()}`,
      contentId,
      authorName: user.name || 'Member',
      authorAvatar: user.avatar,
      text: text.trim(),
      createdAt: 'Just now',
      likes: 0,
      isApproved: true,
    };
    setComments((prev) => [newComm, ...prev]);
    showToast('Comment posted');
  };

  const deleteComment = (commentId: string) => {
    setComments((prev) => prev.filter((c) => c.id !== commentId));
    showToast('Comment removed');
  };

  const toggleCommentApproval = (commentId: string) => {
    setComments((prev) =>
      prev.map((c) => (c.id === commentId ? { ...c, isApproved: !c.isApproved } : c))
    );
  };

  const likeComment = (commentId: string) => {
    setComments((prev) =>
      prev.map((c) => (c.id === commentId ? { ...c, likes: c.likes + 1 } : c))
    );
  };

  // Saved / Bookmarks
  const toggleSaveVideo = (videoId: string) => {
    setUser((prev) => {
      const exists = prev.savedVideoIds.includes(videoId);
      const nextSaved = exists
        ? prev.savedVideoIds.filter((id) => id !== videoId)
        : [...prev.savedVideoIds, videoId];
      showToast(exists ? 'Removed from saved videos' : 'Saved to favorites');
      return { ...prev, savedVideoIds: nextSaved };
    });
  };

  const toggleSaveQuote = (quoteId: string) => {
    setUser((prev) => {
      const exists = prev.savedQuoteIds.includes(quoteId);
      const nextSaved = exists
        ? prev.savedQuoteIds.filter((id) => id !== quoteId)
        : [...prev.savedQuoteIds, quoteId];
      showToast(exists ? 'Removed from saved quotes' : 'Saved to favorites');
      return { ...prev, savedQuoteIds: nextSaved };
    });
  };

  const toggleSaveArticle = (articleId: string) => {
    setUser((prev) => {
      const exists = prev.savedArticleIds.includes(articleId);
      const nextSaved = exists
        ? prev.savedArticleIds.filter((id) => id !== articleId)
        : [...prev.savedArticleIds, articleId];
      showToast(exists ? 'Removed from saved articles' : 'Saved to favorites');
      return { ...prev, savedArticleIds: nextSaved };
    });
  };

  // Push Notifications
  const unreadNotifCount = notifications.filter((n) => !n.read).length;

  const markNotifAsRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  };

  const markAllNotifsAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
    showToast('All notifications marked as read');
  };

  const sendSimulatedPush = (title: string, message: string, type: AppNotification['type']) => {
    const newNotif: AppNotification = {
      id: `notif-${Date.now()}`,
      title,
      message,
      timestamp: 'Just now',
      read: false,
      type,
    };
    setNotifications((prev) => [newNotif, ...prev]);

    // Try browser push notification if permitted
    if ('Notification' in window && Notification.permission === 'granted') {
      try {
        new Notification(`RealityWithEdwin: ${title}`, {
          body: message,
          icon: '/favicon.ico',
        });
      } catch {
        // Fallback gracefully
      }
    }
  };

  const openShareModal = (title: string, text: string, url = window.location.href) => {
    setShareData({ title, text, url });
    setShowShareModal(true);
  };

  return (
    <AppContext.Provider
      value={{
        activeTab,
        setActiveTab,
        user,
        updateUser,
        loginUser,
        logoutUser,
        toggleVIP,
        toggleAdmin,
        videos,
        addVideo,
        likeVideo,
        activeVideo,
        setActiveVideo,
        quotes,
        addQuote,
        likeQuote,
        shareQuote,
        articles,
        addArticle,
        likeArticle,
        activeArticle,
        setActiveArticle,
        stories,
        activeStory,
        setActiveStory,
        comments,
        addComment,
        deleteComment,
        toggleCommentApproval,
        likeComment,
        savedVideoIds: user.savedVideoIds,
        savedQuoteIds: user.savedQuoteIds,
        savedArticleIds: user.savedArticleIds,
        toggleSaveVideo,
        toggleSaveQuote,
        toggleSaveArticle,
        notifications,
        unreadNotifCount,
        markNotifAsRead,
        markAllNotifsAsRead,
        sendSimulatedPush,
        showShareModal,
        setShowShareModal,
        shareData,
        openShareModal,
        showDonationModal,
        setShowDonationModal,
        showAdminModal,
        setShowAdminModal,
        showAdMobBanner,
        setShowAdMobBanner,
        isPhoneFrame,
        setIsPhoneFrame,
        toastMessage,
        showToast,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
