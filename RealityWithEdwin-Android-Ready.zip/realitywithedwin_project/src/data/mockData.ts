import { VideoItem, QuoteItem, RelationshipArticle, CommentItem, UserProfile, AppNotification, EntertainmentStory } from '../types';

export const INITIAL_VIDEOS: VideoItem[] = [
  {
    id: 'vid-1',
    title: 'The Hard Truth About Self-Discipline: Nobody Is Coming to Save You',
    category: 'Discipline & Success',
    duration: '14:22',
    views: 184500,
    likes: 19820,
    thumbnailUrl: '/src/assets/images/edwin_portrait_hero_1794240084548.jpg',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    description: 'In this transformative session, Edwin breaks down why waiting for motivation is a trap. True greatness is forged in the silence of doing what must be done, especially when you do not feel like doing it.',
    speaker: 'Edwin',
    uploadedAt: '2 days ago',
    isTrending: true,
    isRecent: true,
  },
  {
    id: 'vid-2',
    title: 'Loyalty Over Royalty: Why Respect Matters More Than Flattery',
    category: 'Relationship Dynamics',
    duration: '18:45',
    views: 246800,
    likes: 28400,
    thumbnailUrl: '/src/assets/images/relationship_guidance_cover_1794240084554.jpg',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
    description: 'A deep examination of modern relationships, loyalty in seasons of struggle, and why choosing the right partner will either multiply your peace or subtract your purpose.',
    speaker: 'Edwin',
    uploadedAt: '4 days ago',
    isTrending: true,
    isRecent: false,
  },
  {
    id: 'vid-3',
    title: 'When You Walk Through the Storm: Finding Peace in the Pain',
    category: 'Resilience & Pain',
    duration: '11:15',
    views: 92300,
    likes: 12150,
    thumbnailUrl: '/src/assets/images/daily_mindset_sunrise_1794240085142.jpg',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    description: 'Pain is not punishment; it is preparation. Discover how to protect your spirit when life knocks you down and rebuild yourself stronger than before.',
    speaker: 'Edwin',
    uploadedAt: '1 week ago',
    isTrending: false,
    isRecent: true,
  },
  {
    id: 'vid-4',
    title: 'From Empty Pockets to Global Purpose: The Story That Changed My Life',
    category: 'Life Stories',
    duration: '22:10',
    views: 312000,
    likes: 38900,
    thumbnailUrl: '/src/assets/images/community_life_stories_1794240084859.jpg',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
    description: 'Edwin shares raw and unfiltered memories of failure, rejection, and the moment everything shifted when he refused to negotiate with his own potential.',
    speaker: 'Edwin',
    uploadedAt: '2 weeks ago',
    isTrending: true,
    isRecent: false,
  },
  {
    id: 'vid-5',
    title: 'Silence Your Inner Critic: Master Your Mindset in 2026',
    category: 'Focus & Purpose',
    duration: '16:04',
    views: 84200,
    likes: 9410,
    thumbnailUrl: '/src/assets/images/daily_mindset_sunrise_1794240085142.jpg',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4',
    description: 'Your mind can either be your strongest ally or your cruelest jailer. Edwin provides 5 mental anchors to eliminate self-doubt forever.',
    speaker: 'Edwin',
    uploadedAt: '3 weeks ago',
    isTrending: false,
    isRecent: false,
  },
  {
    id: 'vid-6',
    title: 'The Unseen Power of Spiritual Stillness: Guard Your Heart',
    category: 'Spiritual Growth',
    duration: '13:50',
    views: 71200,
    likes: 8320,
    thumbnailUrl: '/src/assets/images/edwin_portrait_hero_1794240084548.jpg',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyBlazes.mp4',
    description: 'How to maintain clarity when the world is noisy. Align your inner soul with divine purpose and watch unshakeable peace follow you.',
    speaker: 'Edwin',
    uploadedAt: '3 weeks ago',
    isTrending: false,
    isRecent: false,
  }
];

export const INITIAL_QUOTES: QuoteItem[] = [
  {
    id: 'quote-1',
    text: "Never let anyone make you feel guilty for outgrowing what used to hurt you. Your growth is your responsibility.",
    author: "Edwin",
    category: "Life Lessons",
    likes: 4210,
    shares: 1840,
    isDailyHighlight: true,
  },
  {
    id: 'quote-2',
    text: "A relationship without mutual respect is an emotional prison. Love without honor will always drain your soul.",
    author: "Edwin",
    category: "Love & Loyalty",
    likes: 3890,
    shares: 1620,
    isDailyHighlight: false,
  },
  {
    id: 'quote-3',
    text: "Do not wait for conditions to be perfect to begin. The fire that tests gold also refines you into a masterpiece.",
    author: "Edwin",
    category: "Success & Focus",
    likes: 2950,
    shares: 1120,
    isDailyHighlight: false,
  },
  {
    id: 'quote-4',
    text: "Forgiveness does not mean welcoming toxic energy back into your life. It means dropping the poison you expected them to drink.",
    author: "Edwin",
    category: "Healing & Strength",
    likes: 5120,
    shares: 2430,
    isDailyHighlight: false,
  },
  {
    id: 'quote-5',
    text: "Your daily habits are voting for the person you will become in five years. Cast your vote wisely every morning.",
    author: "Edwin",
    category: "Positive Thinking",
    likes: 3410,
    shares: 1390,
    isDailyHighlight: false,
  },
  {
    id: 'quote-6',
    text: "Real loyalty is not demonstrated when everything is smooth. It is proven when times get rough and they still choose to stand with you.",
    author: "Edwin",
    category: "Love & Loyalty",
    likes: 4780,
    shares: 2190,
    isDailyHighlight: false,
  }
];

export const INITIAL_ARTICLES: RelationshipArticle[] = [
  {
    id: 'art-1',
    title: 'The 5 Non-Negotiable Pillars of True Emotional Loyalty',
    category: 'Trust & Loyalty',
    readTime: '6 min read',
    summary: 'Loyalty goes beyond physical fidelity. Discover the subtle ways loyalty is shown or broken in everyday conversations, conflict, and silent moments.',
    author: 'Edwin',
    likes: 1290,
    publishedAt: 'Yesterday',
    coverImage: '/src/assets/images/relationship_guidance_cover_1794240084554.jpg',
    content: [
      "In a culture where relationships are treated as disposable, loyalty has become the rarest currency. But most people misunderstand loyalty. Loyalty isn't just staying when it's convenient; it is protecting each other's dignity in private and in public.",
      "1. Guarding Their Name Behind Closed Doors: A truly loyal partner never speaks ill of you to outsiders or allows friends to diminish your worth. They defend you in rooms you haven't yet entered.",
      "2. Transparency in Financial and Emotional Truths: Secrets are the slow leaks that sink the strongest ships. Loyalty means choosing uncomfortable honesty over convenient deception.",
      "3. Consistency in Tough Seasons: When sickness, financial setback, or exhaustion hits, counterfeit loyalty vanishes. Authentic loyalty rolls up its sleeves and stays anchored.",
      "Remember this: You cannot build a castle of love on a foundation of shifting loyalties. Choose someone whose character does not change with their moods."
    ],
    keyTakeaways: [
      "Loyalty is tested when pride is wounded, not when feelings are high.",
      "Never allow third parties to adjudicate your private disagreements.",
      "True loyalty creates emotional safety where vulnerability thrives."
    ]
  },
  {
    id: 'art-2',
    title: 'How to Resolve Conflict Without Destroying Each Other’s Dignity',
    category: 'Communication',
    readTime: '5 min read',
    summary: 'The goal of conflict is not to win an argument, but to understand your partner and protect the union. Learn practical scripts for difficult talks.',
    author: 'Edwin',
    likes: 980,
    publishedAt: '3 days ago',
    coverImage: '/src/assets/images/relationship_guidance_cover_1794240084554.jpg',
    content: [
      "Most couples fight to be right rather than fight to be close. When winning an argument becomes more important than protecting your partner's heart, you have already both lost.",
      "Replace 'You always do this' with 'When this happened, I felt unseen.' Specificity prevents defensiveness.",
      "Take a mandatory 15-minute emotional reset when voices rise above normal conversational volume. Return to the table with curiosity, not artillery.",
      "Apologize without the word 'but'. The word 'but' erases everything that preceded it."
    ],
    keyTakeaways: [
      "Winning an argument against your spouse is winning a battle while burning your own home.",
      "Never attack character; address specific behavior with gentleness.",
      "Curiosity disarms defensiveness faster than accusation."
    ]
  },
  {
    id: 'art-3',
    title: 'Recognizing Green Flags: What Healthy, Mature Love Actually Looks Like',
    category: 'Dating & Marriage',
    readTime: '7 min read',
    summary: 'We spend too much time spotting red flags that we forget how peace, accountability, and emotional maturity feel when they arrive.',
    author: 'Edwin',
    likes: 1540,
    publishedAt: 'Last week',
    coverImage: '/src/assets/images/relationship_guidance_cover_1794240084554.jpg',
    content: [
      "Peace feels boring only to those who are addicted to chaos. When you meet someone whose actions consistently match their words, you don't have to decipher riddles.",
      "Green flag 1: They take accountability without deflecting to your past mistakes.",
      "Green flag 2: They celebrate your wins without feeling intimidated or competitive.",
      "Green flag 3: Disagreements end with clarity and reassurance, not silence or punishment."
    ],
    keyTakeaways: [
      "Healthy love brings clarity, consistency, and a calm nervous system.",
      "Emotional maturity is demonstrated in how someone handles your 'No'.",
      "Look for someone who makes your world feel safe, not chaotic."
    ]
  }
];

export const INITIAL_STORIES: EntertainmentStory[] = [
  {
    id: 'story-1',
    title: 'The Day I Lost Everything and Gained My True Calling',
    storyteller: 'Edwin',
    summary: 'A true story from the winter of 2018 when bankruptcy and broken promises led to an unexpected epiphany on a park bench.',
    fullStory: 'Seven years ago, I looked at an eviction letter in one hand and my phone with twelve missed calls from creditors in the other. I felt like the world had signed an eviction order on my dignity. But that quiet cold bench taught me something no university ever could: rock bottom is not a graveyard—it is solid ground upon which you can pour a foundation that will never crack again...',
    category: 'Turnaround',
    audioDuration: '8:45',
    readTime: '4 min read',
    likes: 2150
  },
  {
    id: 'story-2',
    title: 'The Mother Who Sold Groundnuts to Put Her Son Through Medical School',
    storyteller: 'Reality Community Archive',
    summary: 'Mama Sarah worked 16-hour days under the scorching sun for 12 years. Today, Dr. David performed his 100th open-heart surgery.',
    fullStory: 'In the bustling street markets of Accra, Mama Sarah was known for her smile and her unwavering prayer. While other vendors rested during midday heat, she walked an extra three miles. Today, her son stands in surgical scrubs, dedicating his foundation to the woman with calloused hands who believed in a future she could not yet see...',
    category: 'Faith & Miracles',
    audioDuration: '10:12',
    readTime: '5 min read',
    likes: 3820
  }
];

export const INITIAL_COMMENTS: CommentItem[] = [
  {
    id: 'comm-1',
    contentId: 'vid-1',
    authorName: 'Marcus Adebayo',
    authorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80',
    text: 'Edwin, this hit me straight in the soul. I was about to quit my certification today, but your words reminded me of why I started. God bless this platform!',
    createdAt: '3 hours ago',
    likes: 42,
    isApproved: true,
  },
  {
    id: 'comm-2',
    contentId: 'vid-1',
    authorName: 'Grace M.',
    authorAvatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100&auto=format&fit=crop&q=80',
    text: 'The part about not negotiating with your own potential gave me chills. Watching this from London every morning!',
    createdAt: '6 hours ago',
    likes: 19,
    isApproved: true,
  },
  {
    id: 'comm-3',
    contentId: 'vid-2',
    authorName: 'Kofi Mensah',
    authorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop&q=80',
    text: 'My wife and I watch Edwin together every Sunday evening. Our communication has transformed completely over the past six months.',
    createdAt: '1 day ago',
    likes: 58,
    isApproved: true,
  }
];

export const INITIAL_USER: UserProfile = {
  id: 'user-default',
  name: 'Global Seeker',
  email: 'seeker@realitywithedwin.com',
  avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
  bio: 'Walking in purpose, learning life lessons every day through RealityWithEdwin.',
  country: 'United States',
  joinedDate: 'Joined March 2026',
  isVIP: false,
  isAdmin: false,
  savedVideoIds: ['vid-1', 'vid-2'],
  savedQuoteIds: ['quote-1', 'quote-4'],
  savedArticleIds: ['art-1'],
  notificationSettings: {
    dailyQuotes: true,
    newVideos: true,
    relationshipTips: true,
    vipBroadcasts: false,
  }
};

export const INITIAL_NOTIFICATIONS: AppNotification[] = [
  {
    id: 'notif-1',
    title: 'Daily Motivational Inspiration',
    message: 'Edwin: "Never let anyone make you feel guilty for outgrowing what used to hurt you."',
    timestamp: '8:00 AM Today',
    read: false,
    type: 'quote',
    targetTab: 'quotes',
  },
  {
    id: 'notif-2',
    title: 'New Video Uploaded!',
    message: 'Watch Edwin’s latest video: "The Hard Truth About Self-Discipline"',
    timestamp: 'Yesterday',
    read: false,
    type: 'video',
    targetTab: 'videos',
  },
  {
    id: 'notif-3',
    title: 'Relationship Wisdom Alert',
    message: 'New masterclass published: "The 5 Non-Negotiable Pillars of True Emotional Loyalty"',
    timestamp: '2 days ago',
    read: true,
    type: 'relationship',
    targetTab: 'relationship',
  }
];
