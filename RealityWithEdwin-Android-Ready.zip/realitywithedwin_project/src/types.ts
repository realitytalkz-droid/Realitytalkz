export type NavigationTab = 'home' | 'videos' | 'quotes' | 'relationship' | 'profile' | 'entertainment';

export interface VideoItem {
  id: string;
  title: string;
  category: 'Discipline & Success' | 'Resilience & Pain' | 'Spiritual Growth' | 'Focus & Purpose' | 'Relationship Dynamics' | 'Life Stories';
  duration: string;
  views: number;
  likes: number;
  thumbnailUrl: string;
  videoUrl?: string; // Video URL or sample video
  description: string;
  speaker: string;
  uploadedAt: string;
  isTrending?: boolean;
  isRecent?: boolean;
}

export interface QuoteItem {
  id: string;
  text: string;
  author: string;
  category: 'Life Lessons' | 'Success & Focus' | 'Positive Thinking' | 'Healing & Strength' | 'Love & Loyalty';
  likes: number;
  shares: number;
  isDailyHighlight?: boolean;
}

export interface RelationshipArticle {
  id: string;
  title: string;
  category: 'Trust & Loyalty' | 'Communication' | 'Respect & Boundaries' | 'Healing Heartbreak' | 'Dating & Marriage';
  readTime: string;
  summary: string;
  content: string[];
  keyTakeaways: string[];
  author: string;
  likes: number;
  publishedAt: string;
  coverImage?: string;
}

export interface CommentItem {
  id: string;
  contentId: string;
  authorName: string;
  authorAvatar?: string;
  text: string;
  createdAt: string;
  likes: number;
  isApproved: boolean;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  avatar: string;
  bio: string;
  country: string;
  joinedDate: string;
  isVIP: boolean;
  isAdmin: boolean;
  savedVideoIds: string[];
  savedQuoteIds: string[];
  savedArticleIds: string[];
  notificationSettings: {
    dailyQuotes: boolean;
    newVideos: boolean;
    relationshipTips: boolean;
    vipBroadcasts: boolean;
  };
}

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  type: 'video' | 'quote' | 'relationship' | 'system';
  targetTab?: NavigationTab;
}

export interface EntertainmentStory {
  id: string;
  title: string;
  storyteller: string;
  summary: string;
  fullStory: string;
  category: 'Turnaround' | 'Faith & Miracles' | 'Lesson Learned';
  audioDuration?: string;
  readTime: string;
  likes: number;
}
