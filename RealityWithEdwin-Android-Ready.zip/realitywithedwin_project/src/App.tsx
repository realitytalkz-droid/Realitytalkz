/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { AndroidFrame } from './components/AndroidFrame';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { AdMobBanner } from './components/AdMobBanner';
import { HomeTab } from './components/HomeTab';
import { VideosTab } from './components/VideosTab';
import { QuotesTab } from './components/QuotesTab';
import { RelationshipTab } from './components/RelationshipTab';
import { ProfileTab } from './components/ProfileTab';
import { VideoModal } from './components/VideoModal';
import { ArticleModal } from './components/ArticleModal';
import { ShareModal } from './components/ShareModal';
import { DonationModal } from './components/DonationModal';
import { AdminModal } from './components/AdminModal';

const MainAppContent: React.FC = () => {
  const { activeTab, toastMessage } = useApp();

  return (
    <div className="flex-1 flex flex-col h-full bg-[#09090b] relative overflow-hidden select-none">
      {/* Sticky Top Header */}
      <Header />

      {/* Primary Tab Body */}
      <main className="flex-1 flex flex-col overflow-hidden relative">
        {activeTab === 'home' && <HomeTab />}
        {activeTab === 'videos' && <VideosTab />}
        {activeTab === 'quotes' && <QuotesTab />}
        {activeTab === 'relationship' && <RelationshipTab />}
        {activeTab === 'profile' && <ProfileTab />}
      </main>

      {/* AdMob Banner (Monetization simulation) */}
      <AdMobBanner />

      {/* Bottom Android Navigation */}
      <BottomNav />

      {/* Modals & Dialogs */}
      <VideoModal />
      <ArticleModal />
      <ShareModal />
      <DonationModal />
      <AdminModal />

      {/* Android Native Style Toast Alert */}
      {toastMessage && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 px-4 py-2 bg-[#27272a]/95 text-white text-xs font-semibold rounded-full border border-[#d4af37]/40 shadow-2xl backdrop-blur-md animate-fadeIn flex items-center gap-2 max-w-[90vw] text-center pointer-events-none">
          <span className="w-1.5 h-1.5 rounded-full bg-[#d4af37]" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AndroidFrame>
        <MainAppContent />
      </AndroidFrame>
    </AppProvider>
  );
}
