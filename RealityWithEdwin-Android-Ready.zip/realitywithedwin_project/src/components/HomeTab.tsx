import React from 'react';
import { useApp } from '../context/AppContext';
import { 
  Play, 
  Sparkles, 
  Quote, 
  TrendingUp, 
  Clock, 
  HeartHandshake, 
  ArrowRight, 
  Bookmark, 
  Share2, 
  ThumbsUp, 
  Users, 
  Radio 
} from 'lucide-react';

export const HomeTab: React.FC = () => {
  const { 
    videos, 
    quotes, 
    articles, 
    setActiveVideo, 
    setActiveArticle, 
    setActiveTab, 
    openShareModal, 
    likeQuote, 
    savedQuoteIds, 
    toggleSaveQuote, 
    savedVideoIds, 
    toggleSaveVideo 
  } = useApp();

  const trendingVideos = videos.filter((v) => v.isTrending);
  const recentContent = [...videos.filter((v) => v.isRecent)];
  const dailyQuote = quotes.find((q) => q.isDailyHighlight) || quotes[0];
  const isDailyQuoteSaved = savedQuoteIds.includes(dailyQuote.id);

  return (
    <div className="flex-1 overflow-y-auto no-scrollbar pb-8">
      {/* 1. HERO WELCOME SECTION */}
      <section className="relative px-4 pt-5 pb-6 overflow-hidden">
        {/* Ambient Warm Golden Glow */}
        <div className="absolute top-0 right-0 w-56 h-56 bg-[#d4af37]/15 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#18181b] border border-[#d4af37]/30 text-[#f5e296] text-[11px] font-semibold mb-3">
            <Sparkles className="w-3.5 h-3.5 text-[#d4af37]" />
            <span>Welcome to RealityWithEdwin</span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-heading font-extrabold text-white tracking-tight leading-tight mb-2">
            Transform Your Mind. <br />
            <span className="gold-gradient-text">Master Your Reality.</span>
          </h1>

          <p className="text-xs sm:text-sm text-[#a1a1aa] leading-relaxed max-w-md mb-5">
            Daily motivation, timeless life lessons, entertainment storytelling, and honest relationship wisdom curated by Edwin.
          </p>

          {/* Featured Hero Portrait Card with Direct Play */}
          <div 
            onClick={() => setActiveVideo(videos[0])}
            className="group relative rounded-3xl overflow-hidden border border-[#d4af37]/40 shadow-xl cursor-pointer bg-[#18181b] transition-transform duration-300 active:scale-[0.99]"
          >
            <div className="aspect-[16/9] w-full relative">
              <img
                src="/src/assets/images/edwin_portrait_hero_1794240084548.jpg"
                alt="Edwin Motivational Masterclass"
                className="w-full h-full object-cover object-top transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#09090b] via-[#09090b]/40 to-transparent" />

              {/* Play Badge Overlay */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-14 h-14 rounded-full bg-[#d4af37] text-black flex items-center justify-center shadow-lg shadow-[#d4af37]/40 group-hover:scale-110 group-hover:bg-[#f5e296] transition-all">
                  <Play className="w-6 h-6 fill-black ml-1" />
                </div>
              </div>

              {/* Duration Tag */}
              <span className="absolute bottom-3 right-3 text-[11px] font-bold bg-black/80 backdrop-blur-sm text-[#f5e296] px-2 py-0.5 rounded-md border border-[#27272a]">
                {videos[0].duration}
              </span>

              {/* Speaker Indicator */}
              <div className="absolute top-3 left-3 flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-black/70 backdrop-blur-md border border-[#d4af37]/30 text-[10px] font-bold text-[#f5e296]">
                <Radio className="w-3 h-3 text-red-500 animate-pulse" />
                <span>Featured Teaching by Edwin</span>
              </div>
            </div>

            <div className="p-4 bg-[#121215]">
              <h2 className="text-sm sm:text-base font-heading font-bold text-white group-hover:text-[#f5e296] transition-colors line-clamp-1 mb-1">
                {videos[0].title}
              </h2>
              <p className="text-xs text-[#a1a1aa] line-clamp-2 leading-relaxed">
                {videos[0].description}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 2. DAILY INSPIRATIONAL MESSAGE */}
      <section className="px-4 py-3">
        <div className="flex items-center justify-between mb-2.5">
          <div className="flex items-center gap-1.5 text-xs font-heading font-bold text-white uppercase tracking-wider">
            <Quote className="w-3.5 h-3.5 text-[#d4af37]" />
            <span>Daily Inspirational Message</span>
          </div>
          <button
            onClick={() => setActiveTab('quotes')}
            className="text-[11px] text-[#d4af37] hover:text-[#f5e296] font-semibold flex items-center gap-0.5 transition-colors"
          >
            <span>All Quotes</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>

        <div className="relative rounded-3xl p-5 bg-gradient-to-br from-[#18181b] via-[#121215] to-[#1c1917] border border-[#d4af37]/40 shadow-lg overflow-hidden">
          {/* Subtle quotation background graphic */}
          <div className="absolute -top-3 -right-3 text-[#d4af37]/10 pointer-events-none select-none">
            <Quote className="w-24 h-24 stroke-[1]" />
          </div>

          <div className="relative z-10">
            <span className="text-[10px] font-bold text-[#d4af37] uppercase tracking-widest block mb-2">
              Words of Truth · By Edwin
            </span>

            <p className="text-sm sm:text-base font-serif italic text-[#f4f4f5] leading-relaxed mb-4">
              "{dailyQuote.text}"
            </p>

            <div className="flex items-center justify-between pt-3 border-t border-[#27272a]">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => likeQuote(dailyQuote.id)}
                  className="flex items-center gap-1 text-xs text-[#a1a1aa] hover:text-[#d4af37] transition-colors"
                >
                  <ThumbsUp className="w-3.5 h-3.5" />
                  <span className="tabular-nums">{dailyQuote.likes.toLocaleString()}</span>
                </button>
                <button
                  onClick={() => toggleSaveQuote(dailyQuote.id)}
                  className={`p-1 text-xs transition-colors ${
                    isDailyQuoteSaved ? 'text-[#d4af37]' : 'text-[#a1a1aa] hover:text-white'
                  }`}
                >
                  <Bookmark className={`w-3.5 h-3.5 ${isDailyQuoteSaved ? 'fill-[#d4af37]' : ''}`} />
                </button>
              </div>

              <button
                onClick={() =>
                  openShareModal(
                    'Daily Quote by Edwin',
                    `"${dailyQuote.text}" — Edwin`,
                    window.location.href
                  )
                }
                className="flex items-center gap-1.5 px-3 py-1 bg-[#d4af37]/15 hover:bg-[#d4af37]/25 text-[#f5e296] border border-[#d4af37]/30 rounded-xl text-xs font-semibold transition-colors"
              >
                <Share2 className="w-3 h-3 text-[#d4af37]" />
                <span>Share Quote</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 3. TRENDING MOTIVATIONAL VIDEOS */}
      <section className="px-4 py-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-1.5 text-xs font-heading font-bold text-white uppercase tracking-wider">
            <TrendingUp className="w-3.5 h-3.5 text-[#d4af37]" />
            <span>Trending Motivational Videos</span>
          </div>
          <button
            onClick={() => setActiveTab('videos')}
            className="text-[11px] text-[#d4af37] hover:text-[#f5e296] font-semibold flex items-center gap-0.5 transition-colors"
          >
            <span>See More</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>

        {/* Horizontal Carousel */}
        <div className="flex gap-3 overflow-x-auto no-scrollbar -mx-4 px-4 pb-2">
          {trendingVideos.map((vid) => {
            const isVidSaved = savedVideoIds.includes(vid.id);

            return (
              <div
                key={vid.id}
                className="w-64 sm:w-72 shrink-0 rounded-2xl bg-[#18181b] border border-[#27272a] hover:border-[#d4af37]/40 overflow-hidden flex flex-col group transition-all"
              >
                <div 
                  onClick={() => setActiveVideo(vid)}
                  className="relative aspect-video w-full bg-black cursor-pointer overflow-hidden"
                >
                  <img
                    src={vid.thumbnailUrl}
                    alt={vid.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-black/25 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <div className="w-10 h-10 rounded-full bg-[#d4af37] text-black flex items-center justify-center">
                      <Play className="w-5 h-5 fill-black ml-0.5" />
                    </div>
                  </div>
                  <span className="absolute bottom-2 right-2 text-[10px] font-bold bg-black/80 px-1.5 py-0.5 rounded text-white">
                    {vid.duration}
                  </span>
                  <span className="absolute top-2 left-2 text-[9px] font-bold uppercase tracking-wider bg-[#d4af37] text-black px-1.5 py-0.5 rounded">
                    {vid.category}
                  </span>
                </div>

                <div className="p-3 flex-1 flex flex-col justify-between">
                  <h3
                    onClick={() => setActiveVideo(vid)}
                    className="text-xs font-heading font-bold text-white group-hover:text-[#f5e296] line-clamp-2 leading-snug cursor-pointer mb-2"
                  >
                    {vid.title}
                  </h3>

                  <div className="flex items-center justify-between text-[11px] text-[#71717a] pt-2 border-t border-[#27272a]">
                    <span>{vid.views.toLocaleString()} views</span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleSaveVideo(vid.id);
                      }}
                      className={`p-1 hover:text-[#d4af37] transition-colors ${
                        isVidSaved ? 'text-[#d4af37]' : 'text-[#71717a]'
                      }`}
                    >
                      <Bookmark className={`w-3.5 h-3.5 ${isVidSaved ? 'fill-[#d4af37]' : ''}`} />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* 4. RELATIONSHIP WISDOM HIGHLIGHT */}
      <section className="px-4 py-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-1.5 text-xs font-heading font-bold text-white uppercase tracking-wider">
            <HeartHandshake className="w-3.5 h-3.5 text-[#d4af37]" />
            <span>Relationship Advice & Life Lessons</span>
          </div>
          <button
            onClick={() => setActiveTab('relationship')}
            className="text-[11px] text-[#d4af37] hover:text-[#f5e296] font-semibold flex items-center gap-0.5 transition-colors"
          >
            <span>Explore</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>

        {articles[0] && (
          <div
            onClick={() => setActiveArticle(articles[0])}
            className="group rounded-3xl bg-[#18181b] border border-[#27272a] hover:border-[#d4af37]/40 p-4 sm:p-5 cursor-pointer transition-all flex flex-col sm:flex-row gap-4 items-center"
          >
            <div className="w-full sm:w-36 aspect-video sm:aspect-square rounded-2xl overflow-hidden shrink-0 bg-black">
              <img
                src={articles[0].coverImage || '/src/assets/images/relationship_guidance_cover_1794240084554.jpg'}
                alt={articles[0].title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
            </div>

            <div className="flex-1 w-full">
              <div className="flex items-center gap-2 text-[10px] text-[#d4af37] font-semibold uppercase tracking-wider mb-1">
                <span>{articles[0].category}</span>
                <span>·</span>
                <span className="text-[#a1a1aa] normal-case">{articles[0].readTime}</span>
              </div>

              <h3 className="text-sm sm:text-base font-heading font-bold text-white group-hover:text-[#f5e296] transition-colors leading-snug mb-1.5">
                {articles[0].title}
              </h3>

              <p className="text-xs text-[#a1a1aa] line-clamp-2 leading-relaxed mb-3">
                {articles[0].summary}
              </p>

              <div className="flex items-center text-xs font-semibold text-[#d4af37]">
                <span>Read Masterclass with Edwin →</span>
              </div>
            </div>
          </div>
        )}
      </section>

      {/* 5. RECENTLY UPLOADED CONTENT */}
      <section className="px-4 py-3">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-1.5 text-xs font-heading font-bold text-white uppercase tracking-wider">
            <Clock className="w-3.5 h-3.5 text-[#d4af37]" />
            <span>Recently Uploaded</span>
          </div>
        </div>

        <div className="space-y-2.5">
          {recentContent.slice(0, 3).map((item) => (
            <div
              key={item.id}
              onClick={() => setActiveVideo(item)}
              className="flex items-center gap-3 p-2.5 rounded-2xl bg-[#18181b] hover:bg-[#27272a]/50 border border-[#27272a] cursor-pointer transition-colors"
            >
              <div className="w-20 aspect-video rounded-xl overflow-hidden relative bg-black shrink-0">
                <img src={item.thumbnailUrl} alt={item.title} className="w-full h-full object-cover" />
                <span className="absolute bottom-1 right-1 text-[9px] font-bold bg-black/80 px-1 rounded text-white">
                  {item.duration}
                </span>
              </div>

              <div className="flex-1 min-w-0">
                <span className="text-[10px] text-[#d4af37] font-medium block">
                  {item.category}
                </span>
                <h4 className="text-xs font-heading font-bold text-white truncate">
                  {item.title}
                </h4>
                <p className="text-[10px] text-[#71717a] mt-0.5">
                  Uploaded {item.uploadedAt} · {item.views.toLocaleString()} views
                </p>
              </div>

              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setActiveVideo(item);
                }}
                className="w-8 h-8 rounded-full bg-[#27272a] hover:bg-[#d4af37] hover:text-black flex items-center justify-center text-white shrink-0 transition-colors"
              >
                <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* 6. GLOBAL COMMUNITY REACH TICKER */}
      <section className="mx-4 my-4 p-4 rounded-3xl bg-gradient-to-r from-[#18181b] to-[#121215] border border-[#27272a] text-center">
        <div className="flex items-center justify-center gap-2 text-xs font-bold text-[#f5e296] mb-1">
          <Users className="w-4 h-4 text-[#d4af37]" />
          <span>A Global Community Built on Purpose</span>
        </div>
        <p className="text-[11px] text-[#a1a1aa] max-w-xs mx-auto leading-relaxed">
          Over 350,000+ souls across 84 countries tuning in to Edwin’s reality talks every week.
        </p>
      </section>
    </div>
  );
};
