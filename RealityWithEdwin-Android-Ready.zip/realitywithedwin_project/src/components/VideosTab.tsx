import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Play, 
  Search, 
  Bookmark, 
  Share2, 
  ThumbsUp, 
  Eye, 
  MessageSquare, 
  Filter 
} from 'lucide-react';
import { VideoItem } from '../types';

const CATEGORIES = [
  'All',
  'Discipline & Success',
  'Relationship Dynamics',
  'Resilience & Pain',
  'Focus & Purpose',
  'Spiritual Growth',
  'Life Stories'
];

export const VideosTab: React.FC = () => {
  const { 
    videos, 
    setActiveVideo, 
    likeVideo, 
    savedVideoIds, 
    toggleSaveVideo, 
    openShareModal, 
    comments 
  } = useApp();

  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredVideos = videos.filter((vid) => {
    const matchesCategory = selectedCategory === 'All' || vid.category === selectedCategory;
    const matchesSearch =
      vid.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      vid.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      vid.category.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="flex-1 overflow-y-auto no-scrollbar pb-8">
      {/* Header Banner */}
      <div className="px-4 pt-5 pb-3">
        <h1 className="text-xl sm:text-2xl font-heading font-extrabold text-white tracking-tight mb-1">
          Motivational Video Archive
        </h1>
        <p className="text-xs text-[#a1a1aa]">
          Watch Edwin’s transformative teachings, keynote messages & real-life lessons.
        </p>

        {/* Search Input */}
        <div className="relative mt-3.5 mb-3">
          <Search className="absolute left-3.5 top-2.5 w-4 h-4 text-[#71717a]" />
          <input
            type="text"
            placeholder="Search topics, wisdom or keywords..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#18181b] border border-[#27272a] focus:border-[#d4af37] rounded-2xl pl-10 pr-4 py-2 text-xs text-white placeholder-[#52525b] focus:outline-none transition-colors"
          />
        </div>

        {/* Category Pills */}
        <div className="flex gap-1.5 overflow-x-auto no-scrollbar -mx-4 px-4 pb-1">
          {CATEGORIES.map((cat) => {
            const isSelected = selectedCategory === cat;
            return (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                  isSelected
                    ? 'bg-[#d4af37] text-black shadow-sm'
                    : 'bg-[#18181b] text-[#a1a1aa] hover:text-white border border-[#27272a]'
                }`}
              >
                {cat}
              </button>
            );
          })}
        </div>
      </div>

      {/* Videos List Grid */}
      <div className="px-4 py-2 space-y-4">
        {filteredVideos.length === 0 ? (
          <div className="text-center py-12 rounded-3xl bg-[#18181b] border border-[#27272a] p-6">
            <p className="text-xs text-[#a1a1aa] mb-3">
              No motivational videos found matching "{searchQuery}".
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('All');
              }}
              className="px-4 py-2 bg-[#27272a] hover:bg-[#3f3f46] text-white text-xs font-semibold rounded-xl transition-colors"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          filteredVideos.map((vid) => {
            const isSaved = savedVideoIds.includes(vid.id);
            const vidCommentCount = comments.filter((c) => c.contentId === vid.id).length;

            return (
              <div
                key={vid.id}
                className="group rounded-3xl bg-[#18181b] border border-[#27272a] hover:border-[#d4af37]/40 overflow-hidden shadow-md transition-all flex flex-col"
              >
                {/* Video Media Area */}
                <div
                  onClick={() => setActiveVideo(vid)}
                  className="relative aspect-video w-full bg-black cursor-pointer overflow-hidden"
                >
                  <img
                    src={vid.thumbnailUrl}
                    alt={vid.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-90 group-hover:opacity-100 transition-opacity">
                    <div className="w-12 h-12 rounded-full bg-[#d4af37] text-black flex items-center justify-center shadow-lg shadow-[#d4af37]/30 group-hover:scale-110 transition-transform">
                      <Play className="w-5 h-5 fill-black ml-0.5" />
                    </div>
                  </div>

                  {/* Badges */}
                  <span className="absolute bottom-2.5 right-2.5 text-[10px] font-bold bg-black/85 text-[#f5e296] px-2 py-0.5 rounded-md border border-[#27272a]">
                    {vid.duration}
                  </span>

                  <span className="absolute top-2.5 left-2.5 text-[9px] font-bold uppercase tracking-wider bg-[#09090b]/80 backdrop-blur-sm text-[#d4af37] border border-[#d4af37]/30 px-2 py-0.5 rounded-full">
                    {vid.category}
                  </span>
                </div>

                {/* Details */}
                <div className="p-4 flex-1 flex flex-col justify-between">
                  <div>
                    <h3
                      onClick={() => setActiveVideo(vid)}
                      className="text-sm font-heading font-bold text-white group-hover:text-[#f5e296] cursor-pointer line-clamp-2 leading-snug mb-1.5 transition-colors"
                    >
                      {vid.title}
                    </h3>
                    <p className="text-xs text-[#a1a1aa] line-clamp-2 leading-relaxed mb-3">
                      {vid.description}
                    </p>
                  </div>

                  {/* Actions & Metrics Row */}
                  <div className="flex items-center justify-between pt-3 border-t border-[#27272a] text-xs">
                    <div className="flex items-center gap-3 text-[#71717a]">
                      <span className="flex items-center gap-1">
                        <Eye className="w-3.5 h-3.5" />
                        <span className="tabular-nums">{vid.views.toLocaleString()}</span>
                      </span>
                      <button
                        onClick={() => setActiveVideo(vid)}
                        className="flex items-center gap-1 hover:text-[#d4af37] transition-colors"
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                        <span>{vidCommentCount}</span>
                      </button>
                    </div>

                    <div className="flex items-center gap-1.5">
                      {/* Like */}
                      <button
                        onClick={() => likeVideo(vid.id)}
                        className="p-1.5 rounded-lg bg-[#27272a]/60 hover:bg-[#27272a] text-[#a1a1aa] hover:text-[#d4af37] transition-colors"
                        title="Like video"
                      >
                        <ThumbsUp className="w-3.5 h-3.5" />
                      </button>

                      {/* Save */}
                      <button
                        onClick={() => toggleSaveVideo(vid.id)}
                        className={`p-1.5 rounded-lg bg-[#27272a]/60 hover:bg-[#27272a] transition-colors ${
                          isSaved ? 'text-[#d4af37]' : 'text-[#a1a1aa] hover:text-white'
                        }`}
                        title={isSaved ? 'Remove from favorites' : 'Save to favorites'}
                      >
                        <Bookmark className={`w-3.5 h-3.5 ${isSaved ? 'fill-[#d4af37]' : ''}`} />
                      </button>

                      {/* Share */}
                      <button
                        onClick={() =>
                          openShareModal(
                            vid.title,
                            `Watch Edwin’s motivational session: "${vid.title}"`,
                            window.location.href
                          )
                        }
                        className="p-1.5 rounded-lg bg-[#27272a]/60 hover:bg-[#27272a] text-[#a1a1aa] hover:text-[#d4af37] transition-colors"
                        title="Share video"
                      >
                        <Share2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
