import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Quote, 
  Sparkles, 
  Share2, 
  ThumbsUp, 
  Bookmark, 
  Copy, 
  Check, 
  Shuffle, 
  MessageCircle, 
  Facebook, 
  Instagram, 
  Volume2 
} from 'lucide-react';
import { QuoteItem } from '../types';

const QUOTE_CATEGORIES = [
  'All',
  'Life Lessons',
  'Success & Focus',
  'Positive Thinking',
  'Healing & Strength',
  'Love & Loyalty'
];

export const QuotesTab: React.FC = () => {
  const { 
    quotes, 
    likeQuote, 
    shareQuote, 
    savedQuoteIds, 
    toggleSaveQuote, 
    openShareModal, 
    showToast 
  } = useApp();

  const [selectedCategory, setSelectedCategory] = useState('All');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [cardTheme, setCardTheme] = useState<'gold' | 'black'>('gold');

  const filteredQuotes = quotes.filter(
    (q) => selectedCategory === 'All' || q.category === selectedCategory
  );

  const headlineQuote = quotes.find((q) => q.isDailyHighlight) || quotes[0];

  const handleCopyText = (quote: QuoteItem) => {
    navigator.clipboard.writeText(`"${quote.text}" — Edwin (RealityWithEdwin)`);
    setCopiedId(quote.id);
    showToast('Quote copied to clipboard!');
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleRecite = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(`${text}. Wisdom by Edwin.`);
      utterance.rate = 0.95;
      window.speechSynthesis.speak(utterance);
      showToast('Reciting Edwin’s daily quote...');
    }
  };

  const handleShareSocial = (quote: QuoteItem, platform: 'whatsapp' | 'facebook' | 'instagram') => {
    shareQuote(quote.id);
    const text = `"${quote.text}" — Edwin #RealityWithEdwin`;
    const url = window.location.href;

    if (platform === 'whatsapp') {
      window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(text + '\n' + url)}`, '_blank');
    } else if (platform === 'facebook') {
      window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}&quote=${encodeURIComponent(text)}`, '_blank');
    } else if (platform === 'instagram') {
      navigator.clipboard.writeText(text);
      showToast('Caption copied! Ready to paste on Instagram.');
      window.open('https://instagram.com', '_blank');
    }
  };

  return (
    <div className="flex-1 overflow-y-auto no-scrollbar pb-8">
      {/* Header */}
      <div className="px-4 pt-5 pb-3">
        <div className="flex items-center justify-between mb-1">
          <h1 className="text-xl sm:text-2xl font-heading font-extrabold text-white tracking-tight">
            Daily Quotes & Life Lessons
          </h1>
          <button
            onClick={() => {
              const random = quotes[Math.floor(Math.random() * quotes.length)];
              handleRecite(random.text);
            }}
            title="Recite random wisdom"
            className="p-2 rounded-xl bg-[#18181b] border border-[#27272a] text-[#d4af37] hover:bg-[#27272a] transition-colors"
          >
            <Shuffle className="w-4 h-4" />
          </button>
        </div>
        <p className="text-xs text-[#a1a1aa]">
          Start your morning with focus, resilience, faith, and healthy thinking.
        </p>

        {/* Categories */}
        <div className="flex gap-1.5 overflow-x-auto no-scrollbar -mx-4 px-4 pt-3 pb-1">
          {QUOTE_CATEGORIES.map((cat) => {
            const isSelected = selectedCategory === cat;
            return (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                  isSelected
                    ? 'bg-[#d4af37] text-black shadow-sm'
                    : 'bg-[#18181b] text-[#a1a1aa] hover:text-white border border-[#27272a]'
                }`}
              >
                {cat}
              </button>
            );
          })}
        </div>
      </div>

      {/* Featured Quote of the Day Hero Banner */}
      <div className="px-4 py-2">
        <div className="relative rounded-3xl overflow-hidden border border-[#d4af37]/50 shadow-xl bg-black">
          <img
            src="/src/assets/images/daily_mindset_sunrise_1794240085142.jpg"
            alt="Sunrise Motivation"
            className="w-full h-56 object-cover opacity-45"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#09090b] via-[#09090b]/60 to-transparent" />

          <div className="absolute inset-0 p-5 flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-black/60 backdrop-blur-md border border-[#d4af37]/40 text-[#f5e296] text-[10px] font-bold uppercase tracking-wider">
                <Sparkles className="w-3 h-3 text-[#d4af37]" />
                Quote of the Day
              </span>

              <button
                onClick={() => handleRecite(headlineQuote.text)}
                className="flex items-center gap-1 text-[11px] font-semibold text-[#f5e296] bg-black/60 backdrop-blur-md px-2.5 py-1 rounded-xl border border-[#27272a] hover:bg-[#18181b] transition-colors"
              >
                <Volume2 className="w-3.5 h-3.5 text-[#d4af37]" />
                <span>Listen</span>
              </button>
            </div>

            <div>
              <p className="text-sm sm:text-base font-serif italic text-white leading-relaxed drop-shadow-md mb-3">
                "{headlineQuote.text}"
              </p>
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-[#d4af37] tracking-wider uppercase">
                  — Edwin
                </span>
                <span className="text-[10px] text-[#d4d4d8] bg-black/70 px-2 py-0.5 rounded-md">
                  {headlineQuote.category}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Quotes Cards Feed */}
      <div className="px-4 py-3 space-y-4">
        {filteredQuotes.map((quote) => {
          const isSaved = savedQuoteIds.includes(quote.id);
          const isCopied = copiedId === quote.id;

          return (
            <div
              key={quote.id}
              className="rounded-3xl p-5 bg-[#18181b] border border-[#27272a] hover:border-[#d4af37]/30 transition-all shadow-md flex flex-col justify-between"
            >
              {/* Category & Quotation Mark */}
              <div className="flex items-center justify-between mb-3 text-xs">
                <span className="text-[10px] font-bold text-[#d4af37] uppercase tracking-wider">
                  {quote.category}
                </span>
                <Quote className="w-4 h-4 text-[#71717a]" />
              </div>

              {/* Quote Text */}
              <p className="text-sm sm:text-base font-serif italic text-[#f4f4f5] leading-relaxed mb-4">
                "{quote.text}"
              </p>

              <div className="text-right text-xs font-bold text-[#a1a1aa] mb-4">
                — Edwin
              </div>

              {/* One-Tap Social Sharing Bar (WhatsApp, FB, IG, Copy) */}
              <div className="pt-3 border-t border-[#27272a] flex flex-col gap-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    {/* Like */}
                    <button
                      onClick={() => likeQuote(quote.id)}
                      className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-[#27272a]/60 hover:bg-[#27272a] text-xs text-[#a1a1aa] hover:text-[#d4af37] transition-colors"
                    >
                      <ThumbsUp className="w-3.5 h-3.5" />
                      <span className="tabular-nums">{quote.likes.toLocaleString()}</span>
                    </button>

                    {/* Bookmark */}
                    <button
                      onClick={() => toggleSaveQuote(quote.id)}
                      className={`p-1.5 rounded-xl bg-[#27272a]/60 hover:bg-[#27272a] transition-colors ${
                        isSaved ? 'text-[#d4af37]' : 'text-[#a1a1aa] hover:text-white'
                      }`}
                      title={isSaved ? 'Remove from saved' : 'Save quote'}
                    >
                      <Bookmark className={`w-3.5 h-3.5 ${isSaved ? 'fill-[#d4af37]' : ''}`} />
                    </button>

                    {/* Copy */}
                    <button
                      onClick={() => handleCopyText(quote)}
                      className="p-1.5 rounded-xl bg-[#27272a]/60 hover:bg-[#27272a] text-[#a1a1aa] hover:text-white transition-colors"
                      title="Copy quote text"
                    >
                      {isCopied ? <Check className="w-3.5 h-3.5 text-[#22c55e]" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>

                  {/* Quick Share Icons */}
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => handleShareSocial(quote, 'whatsapp')}
                      title="Share to WhatsApp"
                      className="w-7 h-7 rounded-lg bg-[#22c55e]/20 text-[#22c55e] flex items-center justify-center hover:bg-[#22c55e]/30 transition-colors"
                    >
                      <MessageCircle className="w-3.5 h-3.5 fill-current" />
                    </button>

                    <button
                      onClick={() => handleShareSocial(quote, 'facebook')}
                      title="Share to Facebook"
                      className="w-7 h-7 rounded-lg bg-[#1877f2]/20 text-[#1877f2] flex items-center justify-center hover:bg-[#1877f2]/30 transition-colors"
                    >
                      <Facebook className="w-3.5 h-3.5 fill-current" />
                    </button>

                    <button
                      onClick={() => handleShareSocial(quote, 'instagram')}
                      title="Copy for Instagram"
                      className="w-7 h-7 rounded-lg bg-[#e1306c]/20 text-[#e1306c] flex items-center justify-center hover:bg-[#e1306c]/30 transition-colors"
                    >
                      <Instagram className="w-3.5 h-3.5" />
                    </button>

                    <button
                      onClick={() =>
                        openShareModal(
                          'RealityWithEdwin Wisdom',
                          `"${quote.text}" — Edwin`,
                          window.location.href
                        )
                      }
                      title="More share options"
                      className="w-7 h-7 rounded-lg bg-[#d4af37]/20 text-[#d4af37] flex items-center justify-center hover:bg-[#d4af37]/30 transition-colors"
                    >
                      <Share2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
