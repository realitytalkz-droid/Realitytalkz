import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Sparkles, 
  Volume2, 
  BookOpen, 
  Clock, 
  Share2, 
  ThumbsUp, 
  Headphones, 
  Play, 
  Radio 
} from 'lucide-react';
import { EntertainmentStory } from '../types';

export const EntertainmentTab: React.FC = () => {
  const { stories, openShareModal, showToast } = useApp();
  const [playingStoryId, setPlayingStoryId] = useState<string | null>(null);

  const handlePlayAudio = (story: EntertainmentStory) => {
    if (!('speechSynthesis' in window)) {
      showToast('Audio playback not supported in this browser.');
      return;
    }

    if (playingStoryId === story.id) {
      window.speechSynthesis.cancel();
      setPlayingStoryId(null);
      showToast('Story narration stopped.');
    } else {
      window.speechSynthesis.cancel();
      const textToRead = `${story.title}. Storyteller: ${story.storyteller}. ${story.fullStory}`;
      const utterance = new SpeechSynthesisUtterance(textToRead);
      utterance.rate = 0.95;
      utterance.onend = () => setPlayingStoryId(null);
      utterance.onerror = () => setPlayingStoryId(null);
      window.speechSynthesis.speak(utterance);
      setPlayingStoryId(story.id);
      showToast(`🎙️ Playing narrative: "${story.title}"`);
    }
  };

  return (
    <div className="flex-1 overflow-y-auto no-scrollbar pb-8">
      {/* Header */}
      <div className="px-4 pt-5 pb-3">
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#18181b] border border-[#d4af37]/30 text-[#f5e296] text-[11px] font-semibold w-fit mb-2">
          <Headphones className="w-3.5 h-3.5 text-[#d4af37]" />
          <span>Real-Life Stories & Narratives</span>
        </div>
        <h1 className="text-xl sm:text-2xl font-heading font-extrabold text-white tracking-tight mb-1">
          Entertainment & Life Experiences
        </h1>
        <p className="text-xs text-[#a1a1aa]">
          Riveting narratives of struggle, unexpected miracles, and turning points.
        </p>
      </div>

      {/* Featured Cover Card */}
      <div className="px-4 py-2">
        <div className="relative rounded-3xl overflow-hidden border border-[#d4af37]/40 shadow-xl bg-black">
          <img
            src="/src/assets/images/community_life_stories_1794240084859.jpg"
            alt="Entertainment & Life Stories"
            className="w-full h-48 object-cover opacity-80"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#09090b] via-[#09090b]/50 to-transparent" />
          <div className="absolute bottom-4 left-4 right-4">
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#d4af37] block mb-1">
              Featured Audio Narrative
            </span>
            <h3 className="text-base font-heading font-bold text-white mb-1">
              {stories[0].title}
            </h3>
            <p className="text-xs text-[#d4d4d8] line-clamp-2">
              {stories[0].summary}
            </p>
          </div>
        </div>
      </div>

      {/* Stories Feed */}
      <div className="px-4 py-3 space-y-4">
        {stories.map((story) => {
          const isPlaying = playingStoryId === story.id;

          return (
            <div
              key={story.id}
              className="p-5 rounded-3xl bg-[#18181b] border border-[#27272a] shadow-md flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between text-xs mb-2">
                  <span className="text-[10px] font-bold text-[#d4af37] uppercase tracking-wider">
                    {story.category}
                  </span>
                  <span className="text-[10px] text-[#71717a] flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {story.readTime}
                  </span>
                </div>

                <h3 className="text-sm font-heading font-bold text-white mb-2 leading-snug">
                  {story.title}
                </h3>

                <p className="text-xs text-[#d4d4d8] leading-relaxed mb-4">
                  {story.fullStory}
                </p>
              </div>

              {/* Action Bar */}
              <div className="flex items-center justify-between pt-3 border-t border-[#27272a]">
                <button
                  onClick={() => handlePlayAudio(story)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                    isPlaying
                      ? 'bg-[#d4af37] text-black animate-pulse'
                      : 'bg-[#27272a] hover:bg-[#3f3f46] text-[#f5e296]'
                  }`}
                >
                  <Volume2 className="w-3.5 h-3.5" />
                  <span>{isPlaying ? 'Pause Audio' : `Listen (${story.audioDuration || '6 min'})`}</span>
                </button>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() =>
                      openShareModal(
                        story.title,
                        `Inspiring story from Edwin: "${story.title}"`,
                        window.location.href
                      )
                    }
                    className="p-1.5 rounded-xl bg-[#27272a] hover:bg-[#3f3f46] text-[#a1a1aa] hover:text-[#d4af37] transition-colors"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
