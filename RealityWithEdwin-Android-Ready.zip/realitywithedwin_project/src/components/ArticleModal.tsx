import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  X, 
  ThumbsUp, 
  Bookmark, 
  Share2, 
  Volume2, 
  Clock, 
  CheckCircle2, 
  HeartHandshake 
} from 'lucide-react';

export const ArticleModal: React.FC = () => {
  const { 
    activeArticle, 
    setActiveArticle, 
    likeArticle, 
    savedArticleIds, 
    toggleSaveArticle, 
    openShareModal, 
    showToast 
  } = useApp();

  const [isReadingAudio, setIsReadingAudio] = useState(false);

  if (!activeArticle) return null;

  const isSaved = savedArticleIds.includes(activeArticle.id);

  const toggleSpeechAudio = () => {
    if (!('speechSynthesis' in window)) {
      showToast('Audio reading not supported in this browser.');
      return;
    }

    if (isReadingAudio) {
      window.speechSynthesis.cancel();
      setIsReadingAudio(false);
      showToast('Audio reading paused.');
    } else {
      window.speechSynthesis.cancel();
      const textToRead = `${activeArticle.title}. Wisdom by Edwin. ${activeArticle.summary}. ${activeArticle.content.join(' ')}`;
      const utterance = new SpeechSynthesisUtterance(textToRead);
      utterance.rate = 0.95;
      utterance.pitch = 1.0;
      utterance.onend = () => setIsReadingAudio(false);
      utterance.onerror = () => setIsReadingAudio(false);
      window.speechSynthesis.speak(utterance);
      setIsReadingAudio(true);
      showToast('🎙️ Edwin voice narrative playback started...');
    }
  };

  const handleClose = () => {
    if (isReadingAudio && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setActiveArticle(null);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/95 flex flex-col justify-between sm:p-4 overflow-y-auto no-scrollbar animate-fadeIn">
      {/* Top Bar */}
      <div className="w-full max-w-2xl mx-auto flex items-center justify-between p-3 z-20 shrink-0">
        <div className="flex items-center gap-2">
          <HeartHandshake className="w-4 h-4 text-[#d4af37]" />
          <span className="text-xs font-semibold text-white tracking-wide uppercase">
            Relationship Wisdom Masterclass
          </span>
        </div>
        <button
          onClick={handleClose}
          className="w-9 h-9 rounded-full bg-[#18181b] border border-[#27272a] text-[#a1a1aa] hover:text-white flex items-center justify-center transition-colors"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Article Body */}
      <div className="w-full max-w-2xl mx-auto flex-1 bg-[#09090b] sm:rounded-3xl border sm:border-[#27272a] overflow-hidden shadow-2xl pb-10">
        {/* Cover Photo */}
        {activeArticle.coverImage && (
          <div className="relative aspect-[21/9] w-full overflow-hidden bg-black">
            <img
              src={activeArticle.coverImage}
              alt={activeArticle.title}
              className="w-full h-full object-cover opacity-90"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#09090b] via-[#09090b]/40 to-transparent" />
            <div className="absolute bottom-3 left-4 right-4 flex items-center justify-between text-xs text-[#d4af37]">
              <span className="font-semibold uppercase tracking-wider">{activeArticle.category}</span>
              <span className="flex items-center gap-1 text-[#e4e4e7]">
                <Clock className="w-3.5 h-3.5" />
                {activeArticle.readTime}
              </span>
            </div>
          </div>
        )}

        <div className="p-5 sm:p-8">
          <h1 className="text-xl sm:text-2xl font-heading font-extrabold text-white leading-tight mb-3">
            {activeArticle.title}
          </h1>

          <div className="flex items-center justify-between py-3 border-y border-[#27272a] mb-6">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#d4af37] to-[#aa820a] p-0.5">
                <div className="w-full h-full rounded-full bg-black flex items-center justify-center text-[10px] font-bold text-[#d4af37]">
                  RE
                </div>
              </div>
              <div>
                <p className="text-xs font-bold text-white">By {activeArticle.author}</p>
                <p className="text-[10px] text-[#a1a1aa]">Founder, RealityWithEdwin</p>
              </div>
            </div>

            <button
              onClick={toggleSpeechAudio}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-semibold transition-all ${
                isReadingAudio
                  ? 'bg-[#d4af37] text-black border-[#d4af37] animate-pulse'
                  : 'bg-[#18181b] border-[#27272a] text-[#f5e296] hover:bg-[#27272a]'
              }`}
            >
              <Volume2 className="w-3.5 h-3.5" />
              <span>{isReadingAudio ? 'Stop Audio' : 'Listen to Edwin'}</span>
            </button>
          </div>

          {/* Executive Summary */}
          <div className="p-4 rounded-2xl bg-[#18181b] border border-[#d4af37]/30 text-xs sm:text-sm text-[#f4f4f5] italic mb-6 leading-relaxed">
            "{activeArticle.summary}"
          </div>

          {/* Paragraphs */}
          <div className="space-y-4 text-xs sm:text-sm text-[#d4d4d8] leading-relaxed font-normal mb-8">
            {activeArticle.content.map((p, idx) => (
              <p key={idx}>{p}</p>
            ))}
          </div>

          {/* Key Takeaways */}
          {activeArticle.keyTakeaways && activeArticle.keyTakeaways.length > 0 && (
            <div className="p-5 rounded-2xl bg-[#18181b] border border-[#27272a] mb-8">
              <h3 className="font-heading font-bold text-sm text-[#d4af37] uppercase tracking-wider mb-3">
                Key Actionable Principles
              </h3>
              <ul className="space-y-2">
                {activeArticle.keyTakeaways.map((tip, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-xs text-[#e4e4e7]">
                    <CheckCircle2 className="w-4 h-4 text-[#d4af37] shrink-0 mt-0.5" />
                    <span>{tip}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Action Row */}
          <div className="flex items-center justify-between pt-4 border-t border-[#27272a]">
            <button
              onClick={() => likeArticle(activeArticle.id)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#18181b] hover:bg-[#27272a] text-xs font-semibold text-white border border-[#27272a] transition-colors"
            >
              <ThumbsUp className="w-4 h-4 text-[#d4af37]" />
              <span>{activeArticle.likes.toLocaleString()}</span>
            </button>

            <button
              onClick={() => toggleSaveArticle(activeArticle.id)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold border transition-colors ${
                isSaved
                  ? 'bg-[#d4af37]/15 border-[#d4af37] text-[#f5e296]'
                  : 'bg-[#18181b] border-[#27272a] text-[#f4f4f5] hover:bg-[#27272a]'
              }`}
            >
              <Bookmark className={`w-4 h-4 ${isSaved ? 'fill-[#d4af37] text-[#d4af37]' : ''}`} />
              <span>{isSaved ? 'Saved' : 'Save'}</span>
            </button>

            <button
              onClick={() =>
                openShareModal(
                  activeArticle.title,
                  `Relationship Lesson from Edwin: "${activeArticle.title}"`,
                  window.location.href
                )
              }
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#18181b] hover:bg-[#27272a] text-xs font-semibold text-white border border-[#27272a] transition-colors"
            >
              <Share2 className="w-4 h-4 text-[#d4af37]" />
              <span>Share Article</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
