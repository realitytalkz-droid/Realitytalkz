import React from 'react';
import { useApp } from '../context/AppContext';
import { 
  X, 
  Bell, 
  CheckCheck, 
  Quote, 
  PlaySquare, 
  HeartHandshake, 
  Sparkles, 
  Radio 
} from 'lucide-react';
import { AppNotification } from '../types';

interface NotificationModalProps {
  onClose: () => void;
}

export const NotificationModal: React.FC<NotificationModalProps> = ({ onClose }) => {
  const { 
    notifications, 
    markNotifAsRead, 
    markAllNotifsAsRead, 
    sendSimulatedPush, 
    setActiveTab, 
    showToast 
  } = useApp();

  const handleTestNotification = () => {
    const quotes = [
      'Edwin: "The only limit to your impact is the excuse you refuse to let go of."',
      'Edwin: "Trust is like glass; once broken, you can glue it back, but the cracks are always visible."',
      'Edwin: "Do not fear starting over. This time, you are not starting from scratch; you are starting from experience."'
    ];
    const picked = quotes[Math.floor(Math.random() * quotes.length)];
    sendSimulatedPush('Daily Inspiration Push', picked, 'quote');
    showToast('Simulated push notification delivered!');
  };

  const handleRequestPushPermission = async () => {
    if ('Notification' in window) {
      const permission = await Notification.requestPermission();
      if (permission === 'granted') {
        showToast('Push Notifications enabled successfully on your device!');
        sendSimulatedPush('RealityWithEdwin Notifications Enabled', 'You will now receive daily morning wisdom and video drops.', 'system');
      } else {
        showToast('Notification permission was declined in browser.');
      }
    } else {
      showToast('Notifications are simulated in-app on this device.');
    }
  };

  const handleNotificationClick = (notif: AppNotification) => {
    markNotifAsRead(notif.id);
    if (notif.targetTab) {
      setActiveTab(notif.targetTab);
      onClose();
    }
  };

  const getIcon = (type: AppNotification['type']) => {
    switch (type) {
      case 'video':
        return <PlaySquare className="w-4 h-4 text-[#d4af37]" />;
      case 'quote':
        return <Quote className="w-4 h-4 text-[#60a5fa]" />;
      case 'relationship':
        return <HeartHandshake className="w-4 h-4 text-[#f43f5e]" />;
      default:
        return <Sparkles className="w-4 h-4 text-[#a855f7]" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fadeIn">
      <div 
        className="w-full max-w-md bg-[#121215] border-t sm:border border-[#27272a] sm:rounded-3xl rounded-t-3xl p-6 shadow-2xl relative max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Android Sheet Handle */}
        <div className="w-10 h-1 bg-[#3f3f46] rounded-full mx-auto -mt-2 mb-4 sm:hidden" />

        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-[#27272a] shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-[#18181b] border border-[#27272a] flex items-center justify-center">
              <Bell className="w-4 h-4 text-[#d4af37]" />
            </div>
            <div>
              <h3 className="font-heading font-bold text-white text-base">Notification Center</h3>
              <p className="text-[11px] text-[#a1a1aa]">Real-time daily alerts & video drops</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[#18181b] flex items-center justify-center text-[#a1a1aa] hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Action Controls */}
        <div className="flex items-center justify-between py-3 border-b border-[#27272a]/60 shrink-0 gap-2">
          <button
            onClick={handleTestNotification}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-[#d4af37]/15 hover:bg-[#d4af37]/25 text-[#f5e296] border border-[#d4af37]/30 rounded-xl text-xs font-medium transition-colors"
          >
            <Radio className="w-3.5 h-3.5 text-[#d4af37]" />
            <span>Simulate Push Alert</span>
          </button>

          <button
            onClick={markAllNotifsAsRead}
            className="flex items-center gap-1 text-xs text-[#a1a1aa] hover:text-white transition-colors px-2 py-1"
          >
            <CheckCheck className="w-3.5 h-3.5 text-[#22c55e]" />
            <span>Mark all read</span>
          </button>
        </div>

        {/* Notifications List */}
        <div className="flex-1 overflow-y-auto py-3 space-y-2.5 no-scrollbar">
          {notifications.length === 0 ? (
            <div className="text-center py-12 text-[#71717a] text-xs">
              No notifications yet. You're all caught up!
            </div>
          ) : (
            notifications.map((notif) => (
              <div
                key={notif.id}
                onClick={() => handleNotificationClick(notif)}
                className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex gap-3 ${
                  notif.read
                    ? 'bg-[#18181b]/50 border-[#27272a]/50 text-[#a1a1aa]'
                    : 'bg-[#18181b] border-[#d4af37]/30 text-white shadow-sm'
                }`}
              >
                <div className="w-8 h-8 rounded-xl bg-[#27272a]/60 flex items-center justify-center shrink-0 mt-0.5">
                  {getIcon(notif.type)}
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between gap-1 mb-0.5">
                    <span className="font-semibold text-xs text-white">{notif.title}</span>
                    <span className="text-[10px] text-[#71717a] shrink-0">{notif.timestamp}</span>
                  </div>
                  <p className="text-xs text-[#a1a1aa] leading-relaxed line-clamp-2">
                    {notif.message}
                  </p>
                  {notif.targetTab && (
                    <span className="inline-block mt-1 text-[10px] font-semibold text-[#d4af37]">
                      Tap to open →
                    </span>
                  )}
                </div>
                {!notif.read && (
                  <span className="w-2 h-2 rounded-full bg-[#d4af37] shrink-0 mt-1.5" />
                )}
              </div>
            ))
          )}
        </div>

        {/* Push Permission Prompt Footer */}
        <div className="pt-3 border-t border-[#27272a] shrink-0">
          <button
            onClick={handleRequestPushPermission}
            className="w-full py-2.5 px-3 bg-[#18181b] hover:bg-[#27272a] text-xs font-medium text-[#d4af37] border border-[#d4af37]/30 rounded-xl flex items-center justify-center gap-2 transition-colors"
          >
            <Bell className="w-3.5 h-3.5" />
            <span>Enable System Android Push Notifications</span>
          </button>
        </div>
      </div>
    </div>
  );
};
