import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  X, 
  Copy, 
  Check, 
  Share2, 
  MessageCircle, 
  Youtube, 
  Facebook, 
  Instagram 
} from 'lucide-react';

export const ShareModal: React.FC = () => {
  const { showShareModal, setShowShareModal, shareData, showToast } = useApp();
  const [copied, setCopied] = useState(false);

  if (!showShareModal) return null;

  const title = shareData?.title || 'RealityWithEdwin';
  const text = shareData?.text || 'Inspiring wisdom, motivational videos and life lessons from Edwin!';
  const url = shareData?.url || window.location.href;

  const handleCopy = () => {
    navigator.clipboard.writeText(`${text}\n\n${url}`);
    setCopied(true);
    showToast('Copied to clipboard!');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title,
          text,
          url,
        });
        showToast('Shared successfully!');
        setShowShareModal(false);
      } catch {
        // User cancelled or unsupported
      }
    } else {
      handleCopy();
    }
  };

  const encodedText = encodeURIComponent(`${text} - Watch on RealityWithEdwin: ${url}`);
  const whatsappUrl = `https://api.whatsapp.com/send?text=${encodedText}`;
  const facebookUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}&quote=${encodeURIComponent(text)}`;
  const twitterUrl = `https://twitter.com/intent/tweet?text=${encodedText}`;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fadeIn">
      <div 
        className="w-full max-w-md bg-[#121215] border-t sm:border border-[#27272a] sm:rounded-3xl rounded-t-3xl p-6 shadow-2xl relative max-h-[90vh] overflow-y-auto no-scrollbar"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Android Sheet Handle */}
        <div className="w-10 h-1 bg-[#3f3f46] rounded-full mx-auto -mt-2 mb-4 sm:hidden" />

        <div className="flex items-center justify-between pb-4 border-b border-[#27272a]">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-[#d4af37]/20 border border-[#d4af37]/40 flex items-center justify-center">
              <Share2 className="w-4 h-4 text-[#d4af37]" />
            </div>
            <div>
              <h3 className="font-bold text-white text-base">Share with Friends</h3>
              <p className="text-[11px] text-[#a1a1aa]">Spread inspiration across the globe</p>
            </div>
          </div>
          <button
            onClick={() => setShowShareModal(false)}
            className="w-8 h-8 rounded-full bg-[#18181b] flex items-center justify-center text-[#a1a1aa] hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Preview Card */}
        <div className="my-4 p-3.5 rounded-2xl bg-[#18181b] border border-[#27272a]/70 text-xs">
          <p className="font-semibold text-[#f5e296] mb-1">{title}</p>
          <p className="text-[#d4d4d8] text-xs line-clamp-3 leading-relaxed">"{text}"</p>
        </div>

        {/* Instant Share Channels */}
        <div className="grid grid-cols-4 gap-2 mb-5">
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-[#18181b] hover:bg-[#22c55e]/15 border border-[#27272a] hover:border-[#22c55e]/40 transition-colors group"
          >
            <div className="w-10 h-10 rounded-full bg-[#22c55e]/20 flex items-center justify-center text-[#22c55e] mb-1.5 group-hover:scale-105 transition-transform">
              <MessageCircle className="w-5 h-5 fill-current" />
            </div>
            <span className="text-[10px] font-medium text-[#d4d4d8]">WhatsApp</span>
          </a>

          <a
            href={facebookUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-[#18181b] hover:bg-[#1877f2]/15 border border-[#27272a] hover:border-[#1877f2]/40 transition-colors group"
          >
            <div className="w-10 h-10 rounded-full bg-[#1877f2]/20 flex items-center justify-center text-[#1877f2] mb-1.5 group-hover:scale-105 transition-transform">
              <Facebook className="w-5 h-5 fill-current" />
            </div>
            <span className="text-[10px] font-medium text-[#d4d4d8]">Facebook</span>
          </a>

          <button
            onClick={handleCopy}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-[#18181b] hover:bg-[#e1306c]/15 border border-[#27272a] hover:border-[#e1306c]/40 transition-colors group"
          >
            <div className="w-10 h-10 rounded-full bg-[#e1306c]/20 flex items-center justify-center text-[#e1306c] mb-1.5 group-hover:scale-105 transition-transform">
              <Instagram className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-medium text-[#d4d4d8]">Instagram</span>
          </button>

          <button
            onClick={handleNativeShare}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-[#18181b] hover:bg-[#d4af37]/15 border border-[#27272a] hover:border-[#d4af37]/40 transition-colors group"
          >
            <div className="w-10 h-10 rounded-full bg-[#d4af37]/20 flex items-center justify-center text-[#d4af37] mb-1.5 group-hover:scale-105 transition-transform">
              <Share2 className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-medium text-[#d4af37]">More...</span>
          </button>
        </div>

        {/* Copy Link Bar */}
        <div className="flex items-center gap-2 p-2 bg-[#18181b] rounded-xl border border-[#27272a] mb-5">
          <input
            type="text"
            readOnly
            value={url}
            className="bg-transparent text-xs text-[#a1a1aa] flex-1 px-2 focus:outline-none truncate"
          />
          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#d4af37] text-black font-semibold text-xs hover:bg-[#f5e296] transition-colors shrink-0"
          >
            {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy'}</span>
          </button>
        </div>

        {/* Follow RealityWithEdwin Official Channels */}
        <div className="pt-3 border-t border-[#27272a]">
          <span className="text-[11px] font-semibold text-[#a1a1aa] uppercase tracking-wider block mb-2.5">
            Follow RealityWithEdwin Official
          </span>
          <div className="grid grid-cols-2 gap-2">
            <a
              href="https://www.youtube.com"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 px-3 py-2 rounded-xl bg-[#18181b] hover:bg-[#27272a] text-xs text-[#e4e4e7] border border-[#27272a] transition-colors"
            >
              <Youtube className="w-4 h-4 text-red-500" />
              <span>YouTube Channel</span>
            </a>
            <a
              href="https://www.tiktok.com"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 px-3 py-2 rounded-xl bg-[#18181b] hover:bg-[#27272a] text-xs text-[#e4e4e7] border border-[#27272a] transition-colors"
            >
              <div className="w-4 h-4 rounded-full bg-white text-black font-extrabold flex items-center justify-center text-[9px]">
                d
              </div>
              <span>TikTok @Edwin</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
