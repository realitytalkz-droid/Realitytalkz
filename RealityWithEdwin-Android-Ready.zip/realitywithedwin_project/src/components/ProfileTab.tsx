import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  User, 
  Crown, 
  Settings, 
  Bookmark, 
  Bell, 
  Heart, 
  ShieldCheck, 
  LogOut, 
  Edit3, 
  Check, 
  Play, 
  Quote, 
  BookOpen, 
  Sparkles, 
  Share2, 
  Globe 
} from 'lucide-react';

const AVATAR_OPTIONS = [
  'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
  'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150',
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
  'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150'
];

export const ProfileTab: React.FC = () => {
  const { 
    user, 
    updateUser, 
    loginUser, 
    logoutUser, 
    toggleVIP, 
    toggleAdmin, 
    videos, 
    quotes, 
    articles, 
    setActiveVideo, 
    setActiveArticle, 
    savedVideoIds, 
    savedQuoteIds, 
    savedArticleIds, 
    toggleSaveVideo, 
    toggleSaveQuote, 
    toggleSaveArticle, 
    setShowDonationModal, 
    setShowAdminModal, 
    openShareModal, 
    showToast 
  } = useApp();

  const [savedSubTab, setSavedSubTab] = useState<'videos' | 'quotes' | 'articles'>('videos');
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');

  // Edit form state
  const [name, setName] = useState(user.name);
  const [bio, setBio] = useState(user.bio);
  const [country, setCountry] = useState(user.country);
  const [avatar, setAvatar] = useState(user.avatar);

  // Auth form state
  const [authEmail, setAuthEmail] = useState('');
  const [authName, setAuthName] = useState('');
  const [authPassword, setAuthPassword] = useState('');

  // Notification toggles
  const [dailyQuotesNotif, setDailyQuotesNotif] = useState(user.notificationSettings.dailyQuotes);
  const [newVideosNotif, setNewVideosNotif] = useState(user.notificationSettings.newVideos);
  const [relationshipNotif, setRelationshipNotif] = useState(user.notificationSettings.relationshipTips);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateUser({ name, bio, country, avatar });
    setIsEditingProfile(false);
  };

  const handleAuthSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!authEmail.trim()) return;
    loginUser(authEmail.trim(), authName.trim());
    setIsAuthModalOpen(false);
  };

  const handleToggleNotif = (key: 'dailyQuotes' | 'newVideos' | 'relationshipTips') => {
    let nextVal = false;
    if (key === 'dailyQuotes') {
      nextVal = !dailyQuotesNotif;
      setDailyQuotesNotif(nextVal);
    } else if (key === 'newVideos') {
      nextVal = !newVideosNotif;
      setNewVideosNotif(nextVal);
    } else {
      nextVal = !relationshipNotif;
      setRelationshipNotif(nextVal);
    }

    updateUser({
      notificationSettings: {
        ...user.notificationSettings,
        [key]: nextVal,
      },
    });
    showToast(`Notification setting updated`);
  };

  const savedVideos = videos.filter((v) => savedVideoIds.includes(v.id));
  const savedQuotes = quotes.filter((q) => savedQuoteIds.includes(q.id));
  const savedArticles = articles.filter((a) => savedArticleIds.includes(a.id));

  return (
    <div className="flex-1 overflow-y-auto no-scrollbar pb-10">
      {/* Profile Header Card */}
      <div className="px-4 pt-5 pb-3">
        <div className="p-5 rounded-3xl bg-gradient-to-br from-[#18181b] via-[#121215] to-[#1a1714] border border-[#27272a] shadow-lg relative overflow-hidden">
          {/* Subtle gold badge indicator */}
          <div className="absolute top-4 right-4 flex items-center gap-1.5">
            <button
              onClick={() => setIsEditingProfile(true)}
              className="p-1.5 rounded-lg bg-[#27272a]/60 hover:bg-[#27272a] text-[#a1a1aa] hover:text-white transition-colors"
              title="Edit Profile"
            >
              <Edit3 className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="flex items-center gap-4 mb-4">
            <div className="relative">
              <img
                src={user.avatar}
                alt={user.name}
                className="w-16 h-16 rounded-full object-cover border-2 border-[#d4af37]"
              />
              {user.isVIP && (
                <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-[#d4af37] text-black flex items-center justify-center shadow-md">
                  <Crown className="w-3.5 h-3.5 fill-black" />
                </div>
              )}
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <h2 className="text-base font-heading font-bold text-white truncate">
                  {user.name}
                </h2>
                {user.isVIP && (
                  <span className="text-[9px] font-extrabold uppercase px-1.5 py-0.5 rounded bg-[#d4af37] text-black tracking-wider">
                    VIP
                  </span>
                )}
              </div>
              <p className="text-xs text-[#a1a1aa] truncate">{user.email}</p>
              <div className="flex items-center gap-2 text-[10px] text-[#71717a] mt-1">
                <span className="flex items-center gap-1">
                  <Globe className="w-3 h-3" />
                  {user.country}
                </span>
                <span>·</span>
                <span>{user.joinedDate}</span>
              </div>
            </div>
          </div>

          <p className="text-xs text-[#d4d4d8] leading-relaxed mb-4 italic">
            "{user.bio}"
          </p>

          <div className="flex items-center gap-2">
            <button
              onClick={toggleVIP}
              className={`flex-1 py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
                user.isVIP
                  ? 'bg-[#d4af37]/20 text-[#f5e296] border border-[#d4af37]/40'
                  : 'bg-gradient-to-r from-[#d4af37] to-[#aa820a] text-black shadow-md shadow-[#d4af37]/20 font-bold'
              }`}
            >
              <Crown className="w-3.5 h-3.5" />
              <span>{user.isVIP ? 'VIP Gold Member Active' : 'Upgrade to VIP ($4.99/mo)'}</span>
            </button>

            <button
              onClick={() => {
                if (user.email === 'seeker@realitywithedwin.com') {
                  setIsAuthModalOpen(true);
                } else {
                  logoutUser();
                }
              }}
              className="p-2 rounded-xl bg-[#27272a]/60 hover:bg-[#27272a] text-[#a1a1aa] hover:text-white transition-colors"
              title="Account Switch"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* SAVED FAVORITES HUB */}
      <div className="px-4 py-2">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-heading font-bold text-xs uppercase tracking-wider text-white flex items-center gap-1.5">
            <Bookmark className="w-3.5 h-3.5 text-[#d4af37]" />
            <span>My Saved Library</span>
          </h3>
          <span className="text-[10px] text-[#71717a]">
            {savedVideos.length + savedQuotes.length + savedArticles.length} items saved
          </span>
        </div>

        {/* Sub-tabs */}
        <div className="grid grid-cols-3 gap-1.5 p-1 bg-[#18181b] rounded-2xl border border-[#27272a] mb-3 text-xs">
          <button
            onClick={() => setSavedSubTab('videos')}
            className={`py-1.5 rounded-xl font-semibold transition-all ${
              savedSubTab === 'videos'
                ? 'bg-[#d4af37] text-black shadow-sm'
                : 'text-[#a1a1aa] hover:text-white'
            }`}
          >
            Videos ({savedVideos.length})
          </button>
          <button
            onClick={() => setSavedSubTab('quotes')}
            className={`py-1.5 rounded-xl font-semibold transition-all ${
              savedSubTab === 'quotes'
                ? 'bg-[#d4af37] text-black shadow-sm'
                : 'text-[#a1a1aa] hover:text-white'
            }`}
          >
            Quotes ({savedQuotes.length})
          </button>
          <button
            onClick={() => setSavedSubTab('articles')}
            className={`py-1.5 rounded-xl font-semibold transition-all ${
              savedSubTab === 'articles'
                ? 'bg-[#d4af37] text-black shadow-sm'
                : 'text-[#a1a1aa] hover:text-white'
            }`}
          >
            Guides ({savedArticles.length})
          </button>
        </div>

        {/* Saved Content View */}
        <div className="space-y-2.5">
          {savedSubTab === 'videos' && (
            savedVideos.length === 0 ? (
              <div className="text-center py-8 rounded-2xl bg-[#18181b] border border-[#27272a] text-[#71717a] text-xs">
                No saved videos yet. Tap the bookmark icon on any video to save it here!
              </div>
            ) : (
              savedVideos.map((vid) => (
                <div
                  key={vid.id}
                  onClick={() => setActiveVideo(vid)}
                  className="flex items-center gap-3 p-2.5 rounded-2xl bg-[#18181b] border border-[#27272a] hover:border-[#d4af37]/40 cursor-pointer transition-colors"
                >
                  <div className="w-16 aspect-video rounded-lg overflow-hidden relative bg-black shrink-0">
                    <img src={vid.thumbnailUrl} alt={vid.title} className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="text-xs font-bold text-white truncate">{vid.title}</h4>
                    <p className="text-[10px] text-[#a1a1aa]">{vid.duration} · {vid.category}</p>
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleSaveVideo(vid.id);
                    }}
                    className="p-1 text-[#d4af37] hover:text-red-400 transition-colors"
                  >
                    <Bookmark className="w-4 h-4 fill-current" />
                  </button>
                </div>
              ))
            )
          )}

          {savedSubTab === 'quotes' && (
            savedQuotes.length === 0 ? (
              <div className="text-center py-8 rounded-2xl bg-[#18181b] border border-[#27272a] text-[#71717a] text-xs">
                No saved quotes yet. Favorite quotes in the Quotes tab to build your inspiration deck.
              </div>
            ) : (
              savedQuotes.map((q) => (
                <div
                  key={q.id}
                  className="p-3.5 rounded-2xl bg-[#18181b] border border-[#27272a] flex flex-col justify-between"
                >
                  <p className="text-xs font-serif italic text-white mb-2 leading-relaxed">
                    "{q.text}"
                  </p>
                  <div className="flex items-center justify-between text-[10px] text-[#a1a1aa]">
                    <span>— Edwin · {q.category}</span>
                    <button
                      onClick={() => toggleSaveQuote(q.id)}
                      className="text-[#d4af37] hover:text-red-400 font-semibold"
                    >
                      Remove
                    </button>
                  </div>
                </div>
              ))
            )
          )}

          {savedSubTab === 'articles' && (
            savedArticles.length === 0 ? (
              <div className="text-center py-8 rounded-2xl bg-[#18181b] border border-[#27272a] text-[#71717a] text-xs">
                No saved relationship guides yet. Bookmark articles to review them with your partner.
              </div>
            ) : (
              savedArticles.map((art) => (
                <div
                  key={art.id}
                  onClick={() => setActiveArticle(art)}
                  className="p-3.5 rounded-2xl bg-[#18181b] border border-[#27272a] hover:border-[#d4af37]/40 cursor-pointer flex items-center justify-between"
                >
                  <div className="flex-1 min-w-0 pr-3">
                    <span className="text-[10px] font-semibold text-[#d4af37] block mb-0.5">
                      {art.category}
                    </span>
                    <h4 className="text-xs font-bold text-white truncate">{art.title}</h4>
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleSaveArticle(art.id);
                    }}
                    className="p-1 text-[#d4af37] hover:text-red-400"
                  >
                    <Bookmark className="w-4 h-4 fill-current" />
                  </button>
                </div>
              ))
            )
          )}
        </div>
      </div>

      {/* NOTIFICATION SETTINGS */}
      <div className="px-4 py-4">
        <h3 className="font-heading font-bold text-xs uppercase tracking-wider text-white mb-2.5 flex items-center gap-1.5">
          <Bell className="w-3.5 h-3.5 text-[#d4af37]" />
          <span>Push Notification Preferences</span>
        </h3>

        <div className="space-y-2 p-4 rounded-3xl bg-[#18181b] border border-[#27272a]">
          <div className="flex items-center justify-between py-1">
            <div>
              <p className="text-xs font-semibold text-white">Daily Morning Inspiration</p>
              <p className="text-[10px] text-[#71717a]">Receive Edwin’s quote prompt every morning at 8 AM</p>
            </div>
            <button
              onClick={() => handleToggleNotif('dailyQuotes')}
              className={`w-10 h-5 rounded-full transition-colors relative ${
                dailyQuotesNotif ? 'bg-[#d4af37]' : 'bg-[#27272a]'
              }`}
            >
              <div
                className={`w-3.5 h-3.5 rounded-full bg-black absolute top-0.5 transition-transform ${
                  dailyQuotesNotif ? 'right-1' : 'left-1'
                }`}
              />
            </button>
          </div>

          <div className="flex items-center justify-between py-1 border-t border-[#27272a]">
            <div>
              <p className="text-xs font-semibold text-white">New Motivational Videos</p>
              <p className="text-[10px] text-[#71717a]">Instant alert whenever Edwin drops a new message</p>
            </div>
            <button
              onClick={() => handleToggleNotif('newVideos')}
              className={`w-10 h-5 rounded-full transition-colors relative ${
                newVideosNotif ? 'bg-[#d4af37]' : 'bg-[#27272a]'
              }`}
            >
              <div
                className={`w-3.5 h-3.5 rounded-full bg-black absolute top-0.5 transition-transform ${
                  newVideosNotif ? 'right-1' : 'left-1'
                }`}
              />
            </button>
          </div>

          <div className="flex items-center justify-between py-1 border-t border-[#27272a]">
            <div>
              <p className="text-xs font-semibold text-white">Relationship Wisdom Alerts</p>
              <p className="text-[10px] text-[#71717a]">Guidance on loyalty, trust, and marriage</p>
            </div>
            <button
              onClick={() => handleToggleNotif('relationshipTips')}
              className={`w-10 h-5 rounded-full transition-colors relative ${
                relationshipNotif ? 'bg-[#d4af37]' : 'bg-[#27272a]'
              }`}
            >
              <div
                className={`w-3.5 h-3.5 rounded-full bg-black absolute top-0.5 transition-transform ${
                  relationshipNotif ? 'right-1' : 'left-1'
                }`}
              />
            </button>
          </div>
        </div>
      </div>

      {/* QUICK ADMIN PORTAL SHORTCUT */}
      <div className="px-4 py-2">
        <div className="p-4 rounded-3xl bg-[#18181b] border border-[#27272a] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="w-5 h-5 text-[#d4af37]" />
            <div>
              <h4 className="text-xs font-bold text-white">Administrator Portal</h4>
              <p className="text-[10px] text-[#a1a1aa]">Publish content, moderate & check engagement</p>
            </div>
          </div>
          <button
            onClick={() => setShowAdminModal(true)}
            className="px-3 py-1.5 rounded-xl bg-[#27272a] hover:bg-[#d4af37] hover:text-black text-xs font-semibold text-white transition-colors"
          >
            Open Dashboard
          </button>
        </div>
      </div>

      {/* EDIT PROFILE MODAL */}
      {isEditingProfile && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-[#121215] border border-[#27272a] rounded-3xl p-6 shadow-2xl">
            <h3 className="font-heading font-bold text-white text-base mb-3">Edit Profile</h3>
            <form onSubmit={handleSaveProfile} className="space-y-3">
              <div>
                <label className="text-xs font-medium text-[#a1a1aa] block mb-1">Select Avatar</label>
                <div className="flex gap-2">
                  {AVATAR_OPTIONS.map((av, idx) => (
                    <img
                      key={idx}
                      src={av}
                      alt="Avatar option"
                      onClick={() => setAvatar(av)}
                      className={`w-10 h-10 rounded-full object-cover cursor-pointer border-2 transition-all ${
                        avatar === av ? 'border-[#d4af37] scale-105' : 'border-transparent opacity-60'
                      }`}
                    />
                  ))}
                </div>
              </div>

              <div>
                <label className="text-xs font-medium text-[#a1a1aa] block mb-1">Your Name</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-[#18181b] border border-[#27272a] rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                />
              </div>

              <div>
                <label className="text-xs font-medium text-[#a1a1aa] block mb-1">Country</label>
                <input
                  type="text"
                  value={country}
                  onChange={(e) => setCountry(e.target.value)}
                  className="w-full bg-[#18181b] border border-[#27272a] rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                />
              </div>

              <div>
                <label className="text-xs font-medium text-[#a1a1aa] block mb-1">Personal Bio</label>
                <textarea
                  rows={2}
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  className="w-full bg-[#18181b] border border-[#27272a] rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsEditingProfile(false)}
                  className="flex-1 py-2 bg-[#18181b] hover:bg-[#27272a] text-[#a1a1aa] rounded-xl text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-[#d4af37] text-black font-bold rounded-xl text-xs hover:bg-[#f5e296]"
                >
                  Save Profile
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* LOGIN / REGISTER MODAL */}
      {isAuthModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-[#121215] border border-[#27272a] rounded-3xl p-6 shadow-2xl">
            <h3 className="font-heading font-bold text-white text-base mb-1">
              {authMode === 'login' ? 'Welcome Back' : 'Create an Account'}
            </h3>
            <p className="text-xs text-[#a1a1aa] mb-4">
              Join the global RealityWithEdwin community
            </p>

            <form onSubmit={handleAuthSubmit} className="space-y-3">
              {authMode === 'register' && (
                <div>
                  <label className="text-xs font-medium text-[#a1a1aa] block mb-1">Full Name</label>
                  <input
                    type="text"
                    required
                    placeholder="Marcus Adebayo"
                    value={authName}
                    onChange={(e) => setAuthName(e.target.value)}
                    className="w-full bg-[#18181b] border border-[#27272a] rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                  />
                </div>
              )}

              <div>
                <label className="text-xs font-medium text-[#a1a1aa] block mb-1">Email Address</label>
                <input
                  type="email"
                  required
                  placeholder="yourname@gmail.com"
                  value={authEmail}
                  onChange={(e) => setAuthEmail(e.target.value)}
                  className="w-full bg-[#18181b] border border-[#27272a] rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                />
              </div>

              <div>
                <label className="text-xs font-medium text-[#a1a1aa] block mb-1">Password</label>
                <input
                  type="password"
                  required
                  placeholder="••••••••"
                  value={authPassword}
                  onChange={(e) => setAuthPassword(e.target.value)}
                  className="w-full bg-[#18181b] border border-[#27272a] rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-[#d4af37] text-black font-bold rounded-xl text-xs hover:bg-[#f5e296] transition-colors"
              >
                {authMode === 'login' ? 'Sign In' : 'Register Now'}
              </button>

              <div className="text-center pt-2">
                <button
                  type="button"
                  onClick={() => setAuthMode(authMode === 'login' ? 'register' : 'login')}
                  className="text-xs text-[#d4af37] hover:underline"
                >
                  {authMode === 'login'
                    ? "Don't have an account? Sign up"
                    : 'Already registered? Sign in'}
                </button>
              </div>

              <button
                type="button"
                onClick={() => setIsAuthModalOpen(false)}
                className="w-full py-2 bg-[#18181b] text-xs text-[#71717a] hover:text-white rounded-xl"
              >
                Close
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
