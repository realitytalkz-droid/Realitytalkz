import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Sparkles, X, ExternalLink, Zap } from 'lucide-react';

export const AdMobBanner: React.FC = () => {
  const { showAdMobBanner, setShowAdMobBanner, user, toggleVIP, showToast } = useApp();
  const [isRewardedAdWatching, setIsRewardedAdWatching] = useState(false);
  const [countdown, setCountdown] = useState(5);

  // If user is VIP or banner is hidden, do not render banner
  if (!showAdMobBanner || user.isVIP) return null;

  const triggerRewardedAd = () => {
    setIsRewardedAdWatching(true);
    setCountdown(5);
    const interval = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          setIsRewardedAdWatching(false);
          showToast('🎁 Rewarded Ad Completed! 50 Edwin Purpose Points added.');
          return 5;
        }
        return prev - 1;
      });
    }, 1000);
  };

  return (
    <>
      {/* Banner Strip */}
      <div className="w-full bg-[#18181b] border-t border-b border-[#27272a] px-3 py-1.5 flex items-center justify-between text-xs shrink-0 select-none">
        <div className="flex items-center gap-2 overflow-hidden">
          <span className="bg-[#27272a] text-[#a1a1aa] text-[9px] font-bold px-1 rounded uppercase tracking-wider">
            Ad
          </span>
          <div className="truncate">
            <span className="text-[#f5e296] font-semibold">Masterclass 2026: </span>
            <span className="text-[#a1a1aa] text-[11px]">Unleash Your Unstoppable Resilience with Edwin</span>
          </div>
        </div>

        <div className="flex items-center gap-1.5 shrink-0 ml-2">
          <button
            onClick={triggerRewardedAd}
            title="Simulate Rewarded Video Ad"
            className="flex items-center gap-1 px-2 py-0.5 bg-[#d4af37]/15 hover:bg-[#d4af37]/25 text-[#d4af37] border border-[#d4af37]/30 rounded text-[10px] font-semibold transition-colors"
          >
            <Zap className="w-2.5 h-2.5 fill-[#d4af37]" />
            <span>Bonus Ad</span>
          </button>
          <button
            onClick={toggleVIP}
            title="Go VIP to Remove Ads"
            className="text-[10px] text-[#71717a] hover:text-[#d4af37] underline px-1 transition-colors"
          >
            Remove
          </button>
          <button
            onClick={() => setShowAdMobBanner(false)}
            title="Dismiss test banner"
            className="p-1 text-[#71717a] hover:text-white transition-colors"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Rewarded Video Modal Overlay */}
      {isRewardedAdWatching && (
        <div className="fixed inset-0 z-50 bg-black/95 flex flex-col items-center justify-center p-6 text-center animate-fadeIn">
          <div className="w-full max-w-sm bg-[#18181b] border border-[#d4af37]/50 rounded-2xl p-6 shadow-2xl relative">
            <div className="absolute top-3 right-3 text-xs bg-[#27272a] px-2 py-1 rounded text-[#a1a1aa]">
              Reward in: <span className="font-bold text-[#d4af37]">{countdown}s</span>
            </div>
            <div className="w-12 h-12 rounded-full bg-[#d4af37]/20 border border-[#d4af37] flex items-center justify-center mx-auto mb-4">
              <Sparkles className="w-6 h-6 text-[#d4af37]" />
            </div>
            <h3 className="text-lg font-bold text-white mb-2">Google AdMob Rewarded Placement</h3>
            <p className="text-xs text-[#a1a1aa] mb-4">
              Support RealityWithEdwin by viewing sponsor messages. In production, this connects to your AdMob Unit ID (`ca-app-pub-xxx`).
            </p>
            <div className="w-full bg-[#27272a] h-2 rounded-full overflow-hidden mb-2">
              <div
                className="bg-[#d4af37] h-full transition-all duration-1000"
                style={{ width: `${((5 - countdown) / 5) * 100}%` }}
              />
            </div>
            <span className="text-[10px] text-[#71717a]">Thank you for empowering our community outreach</span>
          </div>
        </div>
      )}
    </>
  );
};
