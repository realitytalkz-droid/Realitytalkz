import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  X, 
  Upload, 
  Quote, 
  FileText, 
  MessageSquare, 
  BarChart3, 
  Trash2, 
  CheckCircle, 
  Plus, 
  Users, 
  TrendingUp, 
  ShieldCheck, 
  Sparkles 
} from 'lucide-react';
import { VideoItem, QuoteItem, RelationshipArticle } from '../types';

export const AdminModal: React.FC = () => {
  const { 
    showAdminModal, 
    setShowAdminModal, 
    addVideo, 
    addQuote, 
    addArticle, 
    comments, 
    deleteComment, 
    toggleCommentApproval, 
    user, 
    toggleAdmin, 
    showToast 
  } = useApp();

  const [activeAdminTab, setActiveAdminTab] = useState<'videos' | 'quotes' | 'articles' | 'comments' | 'analytics'>('videos');

  // Video Form State
  const [videoTitle, setVideoTitle] = useState('');
  const [videoCategory, setVideoCategory] = useState<VideoItem['category']>('Discipline & Success');
  const [videoDuration, setVideoDuration] = useState('12:30');
  const [videoDescription, setVideoDescription] = useState('');
  const [videoThumbnailUrl, setVideoThumbnailUrl] = useState('/src/assets/images/edwin_portrait_hero_1794240084548.jpg');

  // Quote Form State
  const [quoteText, setQuoteText] = useState('');
  const [quoteCategory, setQuoteCategory] = useState<QuoteItem['category']>('Life Lessons');
  const [quoteHighlight, setQuoteHighlight] = useState(false);

  // Article Form State
  const [articleTitle, setArticleTitle] = useState('');
  const [articleCategory, setArticleCategory] = useState<RelationshipArticle['category']>('Trust & Loyalty');
  const [articleSummary, setArticleSummary] = useState('');
  const [articleContent, setArticleContent] = useState('');
  const [articleTakeaways, setArticleTakeaways] = useState('');

  if (!showAdminModal) return null;

  const handleVideoSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!videoTitle.trim()) {
      showToast('Please provide a video title');
      return;
    }
    addVideo({
      title: videoTitle.trim(),
      category: videoCategory,
      duration: videoDuration,
      description: videoDescription || 'Inspirational teaching by Edwin.',
      speaker: 'Edwin',
      thumbnailUrl: videoThumbnailUrl,
      videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    });
    setVideoTitle('');
    setVideoDescription('');
    setShowAdminModal(false);
  };

  const handleQuoteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quoteText.trim()) {
      showToast('Please enter a quote');
      return;
    }
    addQuote({
      text: quoteText.trim(),
      author: 'Edwin',
      category: quoteCategory,
      isDailyHighlight: quoteHighlight,
    });
    setQuoteText('');
    setShowAdminModal(false);
  };

  const handleArticleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!articleTitle.trim() || !articleSummary.trim()) {
      showToast('Please complete article title and summary');
      return;
    }
    const paragraphs = articleContent.split('\n\n').filter((p) => p.trim());
    const takeaways = articleTakeaways.split('\n').filter((t) => t.trim());

    addArticle({
      title: articleTitle.trim(),
      category: articleCategory,
      readTime: '5 min read',
      summary: articleSummary.trim(),
      content: paragraphs.length ? paragraphs : [articleSummary],
      keyTakeaways: takeaways.length ? takeaways : ['Guard your loyalty and keep communication pure.'],
      author: 'Edwin',
      coverImage: '/src/assets/images/relationship_guidance_cover_1794240084554.jpg',
    });
    setArticleTitle('');
    setArticleSummary('');
    setArticleContent('');
    setArticleTakeaways('');
    setShowAdminModal(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fadeIn">
      <div 
        className="w-full max-w-2xl bg-[#121215] border-t sm:border border-[#27272a] sm:rounded-3xl rounded-t-3xl p-5 sm:p-6 shadow-2xl relative max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Android Sheet Handle */}
        <div className="w-10 h-1 bg-[#3f3f46] rounded-full mx-auto -mt-2 mb-3 sm:hidden" />

        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-[#27272a] shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#d4af37] to-[#aa820a] flex items-center justify-center text-black font-bold shadow-md shadow-[#d4af37]/20">
              <ShieldCheck className="w-5 h-5 text-black" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-heading font-bold text-white text-base">Admin Dashboard</h3>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#d4af37]/20 text-[#f5e296] font-semibold border border-[#d4af37]/30">
                  Edwin Studio
                </span>
              </div>
              <p className="text-[11px] text-[#a1a1aa]">Publish media, moderate & track engagement</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {!user.isAdmin && (
              <button
                onClick={toggleAdmin}
                className="text-[11px] px-2.5 py-1 bg-[#d4af37]/20 text-[#f5e296] border border-[#d4af37]/40 rounded-lg hover:bg-[#d4af37]/30 font-medium"
              >
                Enable Admin
              </button>
            )}
            <button
              onClick={() => setShowAdminModal(false)}
              className="w-8 h-8 rounded-full bg-[#18181b] flex items-center justify-center text-[#a1a1aa] hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1.5 py-3 border-b border-[#27272a] shrink-0 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setActiveAdminTab('videos')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
              activeAdminTab === 'videos'
                ? 'bg-[#d4af37] text-black shadow-sm'
                : 'text-[#a1a1aa] hover:bg-[#18181b] hover:text-white'
            }`}
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Upload Video</span>
          </button>

          <button
            onClick={() => setActiveAdminTab('quotes')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
              activeAdminTab === 'quotes'
                ? 'bg-[#d4af37] text-black shadow-sm'
                : 'text-[#a1a1aa] hover:bg-[#18181b] hover:text-white'
            }`}
          >
            <Quote className="w-3.5 h-3.5" />
            <span>Publish Quote</span>
          </button>

          <button
            onClick={() => setActiveAdminTab('articles')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
              activeAdminTab === 'articles'
                ? 'bg-[#d4af37] text-black shadow-sm'
                : 'text-[#a1a1aa] hover:bg-[#18181b] hover:text-white'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Add Article</span>
          </button>

          <button
            onClick={() => setActiveAdminTab('comments')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
              activeAdminTab === 'comments'
                ? 'bg-[#d4af37] text-black shadow-sm'
                : 'text-[#a1a1aa] hover:bg-[#18181b] hover:text-white'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Comments ({comments.length})</span>
          </button>

          <button
            onClick={() => setActiveAdminTab('analytics')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
              activeAdminTab === 'analytics'
                ? 'bg-[#d4af37] text-black shadow-sm'
                : 'text-[#a1a1aa] hover:bg-[#18181b] hover:text-white'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            <span>Analytics</span>
          </button>
        </div>

        {/* Tab Body */}
        <div className="flex-1 overflow-y-auto py-4 no-scrollbar">
          {/* UPLOAD VIDEO TAB */}
          {activeAdminTab === 'videos' && (
            <form onSubmit={handleVideoSubmit} className="space-y-3.5">
              <div>
                <label className="text-xs font-medium text-[#a1a1aa] block mb-1">Video Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Master Your Mindset: Why Adversity Is Your Greatest Teacher"
                  value={videoTitle}
                  onChange={(e) => setVideoTitle(e.target.value)}
                  className="w-full bg-[#18181b] border border-[#27272a] focus:border-[#d4af37] rounded-xl px-3 py-2 text-xs text-white placeholder-[#52525b] focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium text-[#a1a1aa] block mb-1">Category</label>
                  <select
                    value={videoCategory}
                    onChange={(e) => setVideoCategory(e.target.value as any)}
                    className="w-full bg-[#18181b] border border-[#27272a] focus:border-[#d4af37] rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                  >
                    <option value="Discipline & Success">Discipline & Success</option>
                    <option value="Relationship Dynamics">Relationship Dynamics</option>
                    <option value="Resilience & Pain">Resilience & Pain</option>
                    <option value="Focus & Purpose">Focus & Purpose</option>
                    <option value="Spiritual Growth">Spiritual Growth</option>
                    <option value="Life Stories">Life Stories</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-medium text-[#a1a1aa] block mb-1">Duration</label>
                  <input
                    type="text"
                    value={videoDuration}
                    onChange={(e) => setVideoDuration(e.target.value)}
                    className="w-full bg-[#18181b] border border-[#27272a] focus:border-[#d4af37] rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-medium text-[#a1a1aa] block mb-1">Thumbnail Preview</label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    '/src/assets/images/edwin_portrait_hero_1794240084548.jpg',
                    '/src/assets/images/relationship_guidance_cover_1794240084554.jpg',
                    '/src/assets/images/daily_mindset_sunrise_1794240085142.jpg',
                  ].map((thumb, idx) => (
                    <button
                      type="button"
                      key={idx}
                      onClick={() => setVideoThumbnailUrl(thumb)}
                      className={`relative aspect-video rounded-xl overflow-hidden border-2 transition-all ${
                        videoThumbnailUrl === thumb
                          ? 'border-[#d4af37] scale-102 shadow-md'
                          : 'border-transparent opacity-60 hover:opacity-100'
                      }`}
                    >
                      <img src={thumb} alt={`Thumbnail ${idx + 1}`} className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-xs font-medium text-[#a1a1aa] block mb-1">Description</label>
                <textarea
                  rows={2}
                  placeholder="Key lessons, timestamps and Edwin's core takeaway..."
                  value={videoDescription}
                  onChange={(e) => setVideoDescription(e.target.value)}
                  className="w-full bg-[#18181b] border border-[#27272a] focus:border-[#d4af37] rounded-xl px-3 py-2 text-xs text-white placeholder-[#52525b] focus:outline-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-[#d4af37] text-black font-heading font-bold text-xs hover:bg-[#f5e296] transition-colors flex items-center justify-center gap-1.5"
              >
                <Plus className="w-4 h-4" />
                <span>Upload and Notify Subscribers</span>
              </button>
            </form>
          )}

          {/* PUBLISH QUOTE TAB */}
          {activeAdminTab === 'quotes' && (
            <form onSubmit={handleQuoteSubmit} className="space-y-4">
              <div>
                <label className="text-xs font-medium text-[#a1a1aa] block mb-1">Quote Text</label>
                <textarea
                  rows={3}
                  required
                  placeholder="Type an uplifting life lesson, mindset shift or relationship truth..."
                  value={quoteText}
                  onChange={(e) => setQuoteText(e.target.value)}
                  className="w-full bg-[#18181b] border border-[#27272a] focus:border-[#d4af37] rounded-xl px-3 py-2 text-xs text-white placeholder-[#52525b] focus:outline-none"
                />
              </div>

              <div>
                <label className="text-xs font-medium text-[#a1a1aa] block mb-1">Category</label>
                <select
                  value={quoteCategory}
                  onChange={(e) => setQuoteCategory(e.target.value as any)}
                  className="w-full bg-[#18181b] border border-[#27272a] focus:border-[#d4af37] rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                >
                  <option value="Life Lessons">Life Lessons</option>
                  <option value="Success & Focus">Success & Focus</option>
                  <option value="Positive Thinking">Positive Thinking</option>
                  <option value="Healing & Strength">Healing & Strength</option>
                  <option value="Love & Loyalty">Love & Loyalty</option>
                </select>
              </div>

              <div className="flex items-center gap-2 p-3 bg-[#18181b] rounded-xl border border-[#27272a]">
                <input
                  type="checkbox"
                  id="highlightCheck"
                  checked={quoteHighlight}
                  onChange={(e) => setQuoteHighlight(e.target.checked)}
                  className="w-4 h-4 rounded text-[#d4af37] focus:ring-0 bg-[#27272a] border-none"
                />
                <label htmlFor="highlightCheck" className="text-xs text-[#e4e4e7] cursor-pointer">
                  Feature as Today’s Headline Quote of the Day
                </label>
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-[#d4af37] text-black font-heading font-bold text-xs hover:bg-[#f5e296] transition-colors flex items-center justify-center gap-1.5"
              >
                <Quote className="w-4 h-4" />
                <span>Publish to Global Feed</span>
              </button>
            </form>
          )}

          {/* ADD ARTICLE TAB */}
          {activeAdminTab === 'articles' && (
            <form onSubmit={handleArticleSubmit} className="space-y-3.5">
              <div>
                <label className="text-xs font-medium text-[#a1a1aa] block mb-1">Article Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. 5 Tests of Loyalty in Modern Relationships"
                  value={articleTitle}
                  onChange={(e) => setArticleTitle(e.target.value)}
                  className="w-full bg-[#18181b] border border-[#27272a] focus:border-[#d4af37] rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                />
              </div>

              <div>
                <label className="text-xs font-medium text-[#a1a1aa] block mb-1">Category</label>
                <select
                  value={articleCategory}
                  onChange={(e) => setArticleCategory(e.target.value as any)}
                  className="w-full bg-[#18181b] border border-[#27272a] focus:border-[#d4af37] rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                >
                  <option value="Trust & Loyalty">Trust & Loyalty</option>
                  <option value="Communication">Communication</option>
                  <option value="Respect & Boundaries">Respect & Boundaries</option>
                  <option value="Healing Heartbreak">Healing Heartbreak</option>
                  <option value="Dating & Marriage">Dating & Marriage</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-medium text-[#a1a1aa] block mb-1">Brief Summary</label>
                <textarea
                  rows={2}
                  required
                  placeholder="Quick 2-sentence summary of the wisdom shared..."
                  value={articleSummary}
                  onChange={(e) => setArticleSummary(e.target.value)}
                  className="w-full bg-[#18181b] border border-[#27272a] focus:border-[#d4af37] rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                />
              </div>

              <div>
                <label className="text-xs font-medium text-[#a1a1aa] block mb-1">
                  Full Article Content (Separate paragraphs with double Enter)
                </label>
                <textarea
                  rows={4}
                  placeholder="Write Edwin's full message..."
                  value={articleContent}
                  onChange={(e) => setArticleContent(e.target.value)}
                  className="w-full bg-[#18181b] border border-[#27272a] focus:border-[#d4af37] rounded-xl px-3 py-2 text-xs text-white focus:outline-none font-mono"
                />
              </div>

              <div>
                <label className="text-xs font-medium text-[#a1a1aa] block mb-1">
                  Key Actionable Takeaways (One per line)
                </label>
                <textarea
                  rows={2}
                  placeholder="Always prioritize communication over ego&#10;Protect each other in public"
                  value={articleTakeaways}
                  onChange={(e) => setArticleTakeaways(e.target.value)}
                  className="w-full bg-[#18181b] border border-[#27272a] focus:border-[#d4af37] rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-[#d4af37] text-black font-heading font-bold text-xs hover:bg-[#f5e296] transition-colors"
              >
                Publish Masterclass
              </button>
            </form>
          )}

          {/* MODERATE COMMENTS TAB */}
          {activeAdminTab === 'comments' && (
            <div className="space-y-3">
              <p className="text-xs text-[#a1a1aa] mb-2">
                Review community contributions. Toggle approval or remove toxic comments.
              </p>
              {comments.map((comm) => (
                <div key={comm.id} className="p-3 bg-[#18181b] border border-[#27272a] rounded-2xl flex items-start justify-between gap-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-semibold text-white">{comm.authorName}</span>
                      <span className="text-[10px] text-[#71717a]">{comm.createdAt}</span>
                      <span className={`text-[9px] px-1.5 py-0.2 rounded font-bold ${
                        comm.isApproved ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-400'
                      }`}>
                        {comm.isApproved ? 'Approved' : 'Pending'}
                      </span>
                    </div>
                    <p className="text-xs text-[#d4d4d8] leading-relaxed">{comm.text}</p>
                  </div>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => toggleCommentApproval(comm.id)}
                      title={comm.isApproved ? 'Unapprove' : 'Approve'}
                      className="p-1.5 rounded-lg bg-[#27272a] hover:bg-[#3f3f46] text-[#22c55e] transition-colors"
                    >
                      <CheckCircle className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => deleteComment(comm.id)}
                      title="Delete Comment"
                      className="p-1.5 rounded-lg bg-[#27272a] hover:bg-red-500/20 text-red-400 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* ANALYTICS TAB */}
          {activeAdminTab === 'analytics' && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="p-3.5 rounded-2xl bg-[#18181b] border border-[#27272a]">
                  <span className="text-[11px] text-[#a1a1aa] block mb-1">Global Video Views</span>
                  <div className="flex items-baseline gap-2">
                    <span className="text-xl font-heading font-bold text-white tabular-nums">989,400</span>
                    <span className="text-[10px] text-emerald-400 font-bold">+18.4%</span>
                  </div>
                </div>

                <div className="p-3.5 rounded-2xl bg-[#18181b] border border-[#27272a]">
                  <span className="text-[11px] text-[#a1a1aa] block mb-1">Quotes Shared</span>
                  <div className="flex items-baseline gap-2">
                    <span className="text-xl font-heading font-bold text-white tabular-nums">48,210</span>
                    <span className="text-[10px] text-emerald-400 font-bold">+24.1%</span>
                  </div>
                </div>

                <div className="p-3.5 rounded-2xl bg-[#18181b] border border-[#27272a]">
                  <span className="text-[11px] text-[#a1a1aa] block mb-1">Active Community</span>
                  <div className="flex items-baseline gap-2">
                    <span className="text-xl font-heading font-bold text-white tabular-nums">354,200</span>
                    <span className="text-[10px] text-[#d4af37] font-bold">84 Countries</span>
                  </div>
                </div>

                <div className="p-3.5 rounded-2xl bg-[#18181b] border border-[#27272a]">
                  <span className="text-[11px] text-[#a1a1aa] block mb-1">AdMob & Patronage</span>
                  <div className="flex items-baseline gap-2">
                    <span className="text-xl font-heading font-bold text-[#d4af37] tabular-nums">$3,840</span>
                    <span className="text-[10px] text-[#a1a1aa]">This Month</span>
                  </div>
                </div>
              </div>

              {/* Geographic Reach */}
              <div className="p-4 rounded-2xl bg-[#18181b] border border-[#27272a]">
                <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3">
                  Top Audience Locations
                </h4>
                <div className="space-y-2 text-xs">
                  {[
                    { country: 'United States', pct: '38%' },
                    { country: 'United Kingdom', pct: '22%' },
                    { country: 'Nigeria & West Africa', pct: '19%' },
                    { country: 'Canada', pct: '11%' },
                    { country: 'Rest of World', pct: '10%' },
                  ].map((loc, idx) => (
                    <div key={idx} className="flex items-center justify-between">
                      <span className="text-[#d4d4d8]">{loc.country}</span>
                      <div className="flex items-center gap-2">
                        <div className="w-24 bg-[#27272a] h-1.5 rounded-full overflow-hidden">
                          <div className="bg-[#d4af37] h-full" style={{ width: loc.pct }} />
                        </div>
                        <span className="text-[#a1a1aa] text-[10px] w-7 text-right tabular-nums">{loc.pct}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
