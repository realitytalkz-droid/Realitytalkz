import React from 'react';
import { useApp } from '../context/AppContext';
import { NavigationTab } from '../types';
import { 
  Home, 
  PlaySquare, 
  Quote, 
  HeartHandshake, 
  User, 
  Film 
} from 'lucide-react';

interface TabItem {
  id: NavigationTab;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}

const TABS: TabItem[] = [
  { id: 'home', label: 'Home', icon: Home },
  { id: 'videos', label: 'Videos', icon: PlaySquare },
  { id: 'quotes', label: 'Quotes', icon: Quote },
  { id: 'relationship', label: 'Relationship', icon: HeartHandshake },
  { id: 'profile', label: 'Profile', icon: User },
];

export const BottomNav: React.FC = () => {
  const { activeTab, setActiveTab } = useApp();

  return (
    <nav 
      aria-label="Main Navigation"
      className="sticky bottom-0 z-30 w-full bg-[#09090b]/95 backdrop-blur-md border-t border-[#27272a] shrink-0"
    >
      <div className="grid grid-cols-5 items-center h-16 max-w-lg mx-auto px-1">
        {TABS.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className="group relative flex flex-col items-center justify-center min-h-[48px] py-1 transition-all"
            >
              {/* Active Golden Glow Underlay */}
              {isActive && (
                <span className="absolute -top-1 w-8 h-1 bg-gradient-to-r from-transparent via-[#d4af37] to-transparent rounded-full shadow-[0_0_8px_#d4af37]" />
              )}

              <div
                className={`relative p-1 rounded-xl transition-transform duration-200 group-active:scale-95 ${
                  isActive
                    ? 'text-[#d4af37]'
                    : 'text-[#71717a] group-hover:text-[#a1a1aa]'
                }`}
              >
                <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.4px] drop-shadow-[0_2px_8px_rgba(212,175,55,0.4)]' : 'stroke-[1.8px]'}`} />
              </div>

              <span
                className={`text-[10px] tracking-tight leading-none mt-0.5 transition-colors ${
                  isActive
                    ? 'font-bold text-[#f5e296]'
                    : 'font-medium text-[#71717a] group-hover:text-[#a1a1aa]'
                }`}
              >
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
