import React from 'react';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg';
  showSubtitle?: boolean;
  className?: string;
}

export const Logo: React.FC<LogoProps> = ({ size = 'md', showSubtitle = true, className = '' }) => {
  const iconDimensions = size === 'sm' ? 'w-8 h-8' : size === 'lg' ? 'w-14 h-14' : 'w-10 h-10';
  const textScale = size === 'sm' ? 'text-sm' : size === 'lg' ? 'text-2xl' : 'text-base';
  const subScale = size === 'sm' ? 'text-[9px]' : size === 'lg' ? 'text-xs' : 'text-[10px]';

  return (
    <div className={`flex items-center gap-2.5 ${className}`}>
      {/* Luxury Golden Emblem */}
      <div className={`relative ${iconDimensions} shrink-0 rounded-xl bg-gradient-to-br from-[#18181b] via-[#09090b] to-[#18181b] p-0.5 border border-[#d4af37]/40 shadow-md shadow-[#d4af37]/10 flex items-center justify-center`}>
        <svg
          viewBox="0 0 100 100"
          className="w-full h-full text-[#d4af37] drop-shadow-[0_2px_4px_rgba(212,175,55,0.35)]"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Subtle Outer Star Halo */}
          <circle cx="50" cy="50" r="44" stroke="url(#goldGrad)" strokeWidth="1.5" strokeDasharray="3 3" opacity="0.6" />
          
          {/* Diamond Rhombus Compass */}
          <polygon
            points="50,10 88,50 50,90 12,50"
            stroke="url(#goldGrad)"
            strokeWidth="2.5"
            strokeLinejoin="round"
          />

          {/* Inner Golden Wings / Crown */}
          <path
            d="M50 22 L62 44 L50 40 L38 44 Z"
            fill="url(#goldGrad)"
          />

          {/* Monogram 'RWE' Stylized Flame Core */}
          <path
            d="M36 48 L36 74 M36 48 H48 C54 48 56 53 56 57 C56 61 53 64 47 64 H36 M46 64 L56 74"
            stroke="url(#goldGrad)"
            strokeWidth="3.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d="M60 52 L65 72 L70 58 L75 72 L80 52"
            stroke="#ffffff"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
            opacity="0.9"
          />

          <defs>
            <linearGradient id="goldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#fff3c4" />
              <stop offset="45%" stopColor="#e6ca65" />
              <stop offset="85%" stopColor="#d4af37" />
              <stop offset="100%" stopColor="#997d1e" />
            </linearGradient>
          </defs>
        </svg>

        {/* Subtle center golden reflection */}
        <div className="absolute inset-0 rounded-xl bg-gradient-to-t from-transparent via-[#d4af37]/5 to-transparent pointer-events-none" />
      </div>

      {/* Brand Name & Typography */}
      <div className="flex flex-col justify-center">
        <div className="flex items-center gap-1.5 leading-none">
          <span className={`font-brand font-bold tracking-tight text-white ${textScale}`}>
            REALITY
          </span>
          <span className={`font-heading font-extrabold text-[#d4af37] tracking-wider ${textScale} drop-shadow-[0_1px_8px_rgba(212,175,55,0.3)]`}>
            WITH EDWIN
          </span>
        </div>
        {showSubtitle && (
          <span className={`font-medium tracking-[0.2em] text-[#a1a1aa] uppercase mt-0.5 ${subScale}`}>
            Inspiration · Truth · Purpose
          </span>
        )}
      </div>
    </div>
  );
};
