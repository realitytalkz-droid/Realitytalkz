import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  X, 
  ThumbsUp, 
  Bookmark, 
  Share2, 
  MessageSquare, 
  Send, 
  Check, 
  Sparkles, 
  Volume2, 
  Eye, 
  Clock 
} from 'lucide-react';

export const VideoModal: React.FC = () => {
  const { 
    activeVideo, 
    setActiveVideo, 
    likeVideo, 
    savedVideoIds, 
    toggleSaveVideo, 
    openShareModal, 
    comments, 
    addComment, 
    likeComment, 
    user 
  } = useApp();

  const [commentText, setCommentText] = useState('');

  if (!activeVideo) return null;

  const isSaved = savedVideoIds.includes(activeVideo.id);
  const videoComments = comments.filter((c) => c.contentId === activeVideo.id && c.isApproved);

  const handlePostComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) return;
    addComment(activeVideo.id, commentText);
    setCommentText('');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/95 flex flex-col justify-between sm:p-4 overflow-y-auto no-scrollbar animate-fadeIn">
      {/* Top Bar */}
      <div className="w-full max-w-2xl mx-auto flex items-center justify-between p-3 z-20 shrink-0">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
          <span className="text-xs font-semibold text-white tracking-wide uppercase">
            Reality Stream
          </span>
        </div>
        <button
          onClick={() => setActiveVideo(null)}
          className="w-9 h-9 rounded-full bg-[#18181b] border border-[#27272a] text-[#a1a1aa] hover:text-white flex items-center justify-center transition-colors"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Main Container */}
      <div className="w-full max-w-2xl mx-auto flex-1 flex flex-col bg-[#09090b] sm:rounded-3xl border sm:border-[#27272a] overflow-hidden shadow-2xl">
        {/* Video Player */}
        <div className="relative aspect-video w-full bg-black flex items-center justify-center overflow-hidden">
          <video
            controls
            autoPlay
            playsInline
            poster={activeVideo.thumbnailUrl}
            src={activeVideo.videoUrl || 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4'}
            className="w-full h-full object-contain"
          >
            Your browser does not support the video tag.
          </video>
        </div>

        {/* Video Information & Engagement */}
        <div className="p-4 sm:p-6 flex-1 flex flex-col">
          {/* Metadata */}
          <div className="flex items-center gap-2 text-xs text-[#a1a1aa] mb-2">
            <span className="text-[#d4af37] font-semibold">{activeVideo.category}</span>
            <span>·</span>
            <span className="flex items-center gap-1">
              <Eye className="w-3.5 h-3.5" />
              {activeVideo.views.toLocaleString()} views
            </span>
            <span>·</span>
            <span>{activeVideo.uploadedAt}</span>
          </div>

          <h2 className="text-base sm:text-xl font-heading font-bold text-white leading-snug mb-3">
            {activeVideo.title}
          </h2>

          <p className="text-xs sm:text-sm text-[#a1a1aa] leading-relaxed mb-5">
            {activeVideo.description}
          </p>

          {/* Action Row */}
          <div className="flex items-center justify-between py-3 border-y border-[#27272a] mb-5">
            <button
              onClick={() => likeVideo(activeVideo.id)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#18181b] hover:bg-[#27272a] text-xs font-semibold text-[#f4f4f5] border border-[#27272a] transition-colors"
            >
              <ThumbsUp className="w-4 h-4 text-[#d4af37]" />
              <span>{activeVideo.likes.toLocaleString()}</span>
            </button>

            <button
              onClick={() => toggleSaveVideo(activeVideo.id)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold border transition-colors ${
                isSaved
                  ? 'bg-[#d4af37]/15 border-[#d4af37] text-[#f5e296]'
                  : 'bg-[#18181b] border-[#27272a] text-[#f4f4f5] hover:bg-[#27272a]'
              }`}
            >
              <Bookmark className={`w-4 h-4 ${isSaved ? 'fill-[#d4af37] text-[#d4af37]' : ''}`} />
              <span>{isSaved ? 'Saved' : 'Save'}</span>
            </button>

            <button
              onClick={() =>
                openShareModal(
                  activeVideo.title,
                  `Watch "${activeVideo.title}" by Edwin on RealityWithEdwin:`,
                  window.location.href
                )
              }
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#18181b] hover:bg-[#27272a] text-xs font-semibold text-[#f4f4f5] border border-[#27272a] transition-colors"
            >
              <Share2 className="w-4 h-4 text-[#d4af37]" />
              <span>Share</span>
            </button>
          </div>

          {/* Comments Section */}
          <div className="flex-1 flex flex-col">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-heading font-bold text-sm text-white flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-[#d4af37]" />
                Community Discussion ({videoComments.length})
              </h3>
              <span className="text-[11px] text-[#71717a]">Keep comments respectful</span>
            </div>

            {/* Comment Input */}
            <form onSubmit={handlePostComment} className="flex gap-2 mb-4">
              <input
                type="text"
                placeholder="Share your thought or how this touched you..."
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
                className="flex-1 bg-[#18181b] border border-[#27272a] focus:border-[#d4af37] rounded-xl px-3 py-2.5 text-xs text-white placeholder-[#52525b] focus:outline-none"
              />
              <button
                type="submit"
                disabled={!commentText.trim()}
                className="px-3.5 py-2.5 rounded-xl bg-[#d4af37] text-black font-semibold text-xs hover:bg-[#f5e296] disabled:opacity-40 transition-colors flex items-center justify-center"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>

            {/* Comments List */}
            <div className="space-y-3 max-h-56 overflow-y-auto no-scrollbar pr-1">
              {videoComments.length === 0 ? (
                <div className="text-center py-6 text-[#71717a] text-xs">
                  Be the first to share how Edwin’s message inspired you today!
                </div>
              ) : (
                videoComments.map((comm) => (
                  <div key={comm.id} className="p-3 rounded-2xl bg-[#18181b] border border-[#27272a]/60 flex gap-2.5">
                    <img
                      src={comm.authorAvatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100'}
                      alt={comm.authorName}
                      className="w-7 h-7 rounded-full object-cover border border-[#27272a] shrink-0"
                    />
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-0.5">
                        <span className="text-xs font-semibold text-[#f5e296]">{comm.authorName}</span>
                        <span className="text-[10px] text-[#71717a]">{comm.createdAt}</span>
                      </div>
                      <p className="text-xs text-[#d4d4d8] leading-relaxed">{comm.text}</p>
                      <button
                        onClick={() => likeComment(comm.id)}
                        className="flex items-center gap-1 text-[10px] text-[#a1a1aa] hover:text-[#d4af37] mt-1 transition-colors"
                      >
                        <ThumbsUp className="w-2.5 h-2.5" />
                        <span>{comm.likes} likes</span>
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
