import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  HeartHandshake, 
  ShieldCheck, 
  Heart, 
  HelpCircle, 
  CheckCircle2, 
  Send, 
  Clock, 
  ThumbsUp, 
  Sparkles, 
  ChevronRight 
} from 'lucide-react';

const PRACTICAL_TIPS = [
  {
    title: '5 Rules of Conflict Without Cruelty',
    category: 'Communication',
    tips: [
      'Never bring up past forgiven mistakes during a current disagreement.',
      'If your voice raises, lower your volume instead of demanding they listen.',
      'Take a 20-minute pause if heart rates spike—never make permanent decisions in temporary fury.',
      'Replace "You never help" with "I feel overwhelmed and would love your support today."'
    ]
  },
  {
    title: 'The Loyalty Compass: 4 Everyday Tests',
    category: 'Trust & Loyalty',
    tips: [
      'Protect their dignity in private conversations with family and friends.',
      'Honesty in small things (money, phone habits, friendships) prevents big betrayals.',
      'Celebrate their successes when they shine brighter than you.',
      'Stand by them when their season is difficult and their strength is low.'
    ]
  },
  {
    title: 'Recognizing Mutual Respect',
    category: 'Respect',
    tips: [
      'They honor your "No" without giving you the silent treatment.',
      'They value your opinions even when they choose a different approach.',
      'They never insult your character, intelligence, or upbringing.',
      'They actively make space for your dreams and personal growth.'
    ]
  }
];

export const RelationshipTab: React.FC = () => {
  const { articles, setActiveArticle, showToast } = useApp();

  const [questionText, setQuestionText] = useState('');
  const [questionTopic, setQuestionTopic] = useState('Trust & Loyalty');
  const [isAnonymous, setIsAnonymous] = useState(true);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [selectedPillar, setSelectedPillar] = useState('All');

  const filteredArticles = articles.filter(
    (a) => selectedPillar === 'All' || a.category === selectedPillar
  );

  const handleQuestionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!questionText.trim()) return;
    setIsSubmitted(true);
    showToast('Relationship question submitted anonymously to Edwin’s review queue!');
    setTimeout(() => {
      setQuestionText('');
      setIsSubmitted(false);
    }, 3500);
  };

  return (
    <div className="flex-1 overflow-y-auto no-scrollbar pb-8">
      {/* Header Banner */}
      <div className="px-4 pt-5 pb-3">
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#18181b] border border-[#d4af37]/30 text-[#f5e296] text-[11px] font-semibold w-fit mb-2">
          <Heart className="w-3.5 h-3.5 text-[#d4af37] fill-[#d4af37]" />
          <span>Love · Loyalty · Trust · Respect</span>
        </div>
        <h1 className="text-xl sm:text-2xl font-heading font-extrabold text-white tracking-tight mb-1">
          Relationship Wisdom by Edwin
        </h1>
        <p className="text-xs text-[#a1a1aa]">
          Cultivating emotional maturity, lasting fidelity, and peace in modern romance.
        </p>

        {/* Pillar Filter Pills */}
        <div className="flex gap-1.5 overflow-x-auto no-scrollbar -mx-4 px-4 pt-3 pb-1">
          {['All', 'Trust & Loyalty', 'Communication', 'Respect & Boundaries', 'Dating & Marriage'].map((pillar) => {
            const isSelected = selectedPillar === pillar;
            return (
              <button
                key={pillar}
                onClick={() => setSelectedPillar(pillar)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                  isSelected
                    ? 'bg-[#d4af37] text-black shadow-sm'
                    : 'bg-[#18181b] text-[#a1a1aa] hover:text-white border border-[#27272a]'
                }`}
              >
                {pillar}
              </button>
            );
          })}
        </div>
      </div>

      {/* Featured Cover Hero */}
      <div className="px-4 py-2">
        <div
          onClick={() => articles[0] && setActiveArticle(articles[0])}
          className="group relative rounded-3xl overflow-hidden border border-[#d4af37]/40 shadow-xl cursor-pointer bg-black"
        >
          <div className="aspect-[16/8] w-full relative">
            <img
              src="/src/assets/images/relationship_guidance_cover_1794240084554.jpg"
              alt="Relationship Guidance"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 opacity-90"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#09090b] via-[#09090b]/40 to-transparent" />

            <div className="absolute bottom-3 left-4 right-4">
              <span className="text-[10px] font-bold uppercase tracking-wider text-[#d4af37] block mb-1">
                Featured Masterclass
              </span>
              <h2 className="text-sm sm:text-lg font-heading font-bold text-white group-hover:text-[#f5e296] leading-snug line-clamp-2">
                {articles[0]?.title || 'The 5 Non-Negotiable Pillars of True Emotional Loyalty'}
              </h2>
            </div>
          </div>
        </div>
      </div>

      {/* Relationship Masterclasses List */}
      <div className="px-4 py-3 space-y-3">
        <h3 className="text-xs font-heading font-bold text-white uppercase tracking-wider mb-2">
          Wisdom Articles & Guides
        </h3>

        {filteredArticles.map((art) => (
          <div
            key={art.id}
            onClick={() => setActiveArticle(art)}
            className="p-4 rounded-2xl bg-[#18181b] border border-[#27272a] hover:border-[#d4af37]/40 cursor-pointer transition-all flex flex-col justify-between group"
          >
            <div>
              <div className="flex items-center justify-between text-[11px] mb-1.5">
                <span className="font-semibold text-[#d4af37]">{art.category}</span>
                <span className="text-[#71717a] flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {art.readTime}
                </span>
              </div>
              <h4 className="text-sm font-heading font-bold text-white group-hover:text-[#f5e296] transition-colors leading-snug mb-1">
                {art.title}
              </h4>
              <p className="text-xs text-[#a1a1aa] line-clamp-2 leading-relaxed">
                {art.summary}
              </p>
            </div>

            <div className="flex items-center justify-between pt-3 mt-3 border-t border-[#27272a] text-xs">
              <span className="text-[10px] text-[#71717a]">By {art.author}</span>
              <span className="text-xs font-semibold text-[#d4af37] flex items-center gap-0.5 group-hover:translate-x-0.5 transition-transform">
                Read Guide <ChevronRight className="w-3.5 h-3.5" />
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Practical Relationship Tips Checklist */}
      <div className="px-4 py-4">
        <h3 className="text-xs font-heading font-bold text-white uppercase tracking-wider mb-3 flex items-center gap-1.5">
          <ShieldCheck className="w-4 h-4 text-[#d4af37]" />
          <span>Practical Relationship Blueprints</span>
        </h3>

        <div className="space-y-3">
          {PRACTICAL_TIPS.map((tipGroup, idx) => (
            <div key={idx} className="p-4 rounded-2xl bg-[#18181b] border border-[#27272a]">
              <div className="flex items-center justify-between mb-2.5">
                <h4 className="text-xs font-bold text-[#f5e296]">{tipGroup.title}</h4>
                <span className="text-[10px] text-[#71717a] uppercase font-semibold">
                  {tipGroup.category}
                </span>
              </div>
              <ul className="space-y-2">
                {tipGroup.tips.map((t, tIdx) => (
                  <li key={tIdx} className="flex items-start gap-2 text-xs text-[#d4d4d8] leading-relaxed">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#d4af37] shrink-0 mt-0.5" />
                    <span>{t}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>

      {/* "Ask Edwin" Anonymous Advice Form */}
      <div className="px-4 py-4">
        <div className="rounded-3xl p-5 bg-gradient-to-br from-[#18181b] via-[#121215] to-[#1e1b18] border border-[#d4af37]/30 shadow-lg">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-8 h-8 rounded-xl bg-[#d4af37]/20 border border-[#d4af37]/40 flex items-center justify-center text-[#d4af37]">
              <HelpCircle className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-heading font-bold text-white text-sm">Ask Edwin (Relationship Q&A)</h3>
              <p className="text-[11px] text-[#a1a1aa]">Get guidance on Edwin's upcoming live session</p>
            </div>
          </div>

          {!isSubmitted ? (
            <form onSubmit={handleQuestionSubmit} className="space-y-3 mt-3">
              <div>
                <select
                  value={questionTopic}
                  onChange={(e) => setQuestionTopic(e.target.value)}
                  className="w-full bg-[#09090b] border border-[#27272a] rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                >
                  <option value="Trust & Loyalty">Topic: Rebuilding Broken Trust & Loyalty</option>
                  <option value="Conflict & Blame">Topic: Stopping Recurring Arguments</option>
                  <option value="Dating & Red Flags">Topic: Dating Red Flags vs Overthinking</option>
                  <option value="Marriage & Commitment">Topic: Preparing for Marriage</option>
                </select>
              </div>

              <div>
                <textarea
                  rows={3}
                  required
                  placeholder="Describe your situation in complete confidence..."
                  value={questionText}
                  onChange={(e) => setQuestionText(e.target.value)}
                  className="w-full bg-[#09090b] border border-[#27272a] focus:border-[#d4af37] rounded-xl px-3 py-2 text-xs text-white placeholder-[#52525b] focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-between text-xs">
                <label className="flex items-center gap-1.5 text-[#a1a1aa] cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isAnonymous}
                    onChange={(e) => setIsAnonymous(e.target.checked)}
                    className="w-3.5 h-3.5 rounded text-[#d4af37] bg-[#27272a] border-none"
                  />
                  <span>Submit 100% Anonymously</span>
                </label>

                <button
                  type="submit"
                  disabled={!questionText.trim()}
                  className="px-4 py-2 bg-[#d4af37] hover:bg-[#f5e296] text-black font-semibold text-xs rounded-xl flex items-center gap-1.5 transition-colors disabled:opacity-40"
                >
                  <Send className="w-3 h-3" />
                  <span>Send to Edwin</span>
                </button>
              </div>
            </form>
          ) : (
            <div className="p-4 text-center">
              <Sparkles className="w-6 h-6 text-[#d4af37] mx-auto mb-2" />
              <h4 className="text-sm font-bold text-white mb-1">Your Question Was Received</h4>
              <p className="text-xs text-[#a1a1aa]">
                Edwin reviews submissions weekly. Answers are addressed during live video broadcasts and podcast releases.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
