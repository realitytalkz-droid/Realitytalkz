import React from 'react';

interface AndroidFrameProps {
  children: React.ReactNode;
}

/**
 * Full-screen app shell. The original AI Studio preview included a decorative
 * phone mockup; that frame is removed in the native build so the app uses the
 * actual device screen instead of showing a phone inside a phone.
 */
export const AndroidFrame: React.FC<AndroidFrameProps> = ({ children }) => {
  return (
    <div className="min-h-[100dvh] w-full bg-[#050507] text-[#f4f4f5] flex flex-col overflow-hidden">
      <div className="flex-1 min-h-0 w-full flex flex-col">
        {children}
      </div>
    </div>
  );
};
