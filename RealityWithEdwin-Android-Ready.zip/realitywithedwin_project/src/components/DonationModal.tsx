import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { X, Heart, ShieldCheck, Sparkles, CreditCard, Gift } from 'lucide-react';
import confetti from 'canvas-confetti';

const PRESETS = [
  { amount: 5, label: 'Cup of Coffee', desc: 'Energize Edwin’s morning recording' },
  { amount: 25, label: 'Media Mission', desc: 'Fund video production & audio gear' },
  { amount: 50, label: 'Community Patron', desc: 'Sponsor youth mentorship outreach' },
  { amount: 100, label: 'Pillar Partner', desc: 'Global translation & book prints' },
];

export const DonationModal: React.FC = () => {
  const { showDonationModal, setShowDonationModal, toggleVIP, user, showToast } = useApp();
  const [selectedAmount, setSelectedAmount] = useState<number>(25);
  const [customAmount, setCustomAmount] = useState<string>('');
  const [supporterName, setSupporterName] = useState<string>(user.name || '');
  const [message, setMessage] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [donated, setDonated] = useState(false);

  if (!showDonationModal) return null;

  const finalAmount = customAmount ? parseFloat(customAmount) || 0 : selectedAmount;

  const handleDonate = (e: React.FormEvent) => {
    e.preventDefault();
    if (finalAmount <= 0) {
      showToast('Please select or enter a donation amount');
      return;
    }

    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      setDonated(true);
      if (!user.isVIP) {
        toggleVIP();
      }
      try {
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#d4af37', '#ffffff', '#e6ca65', '#997d1e'],
        });
      } catch {
        // Fallback
      }
      showToast(`Thank you for your generous $${finalAmount} contribution!`);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fadeIn">
      <div 
        className="w-full max-w-md bg-[#121215] border-t sm:border border-[#27272a] sm:rounded-3xl rounded-t-3xl p-6 shadow-2xl relative max-h-[90vh] overflow-y-auto no-scrollbar"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={() => {
            setDonated(false);
            setShowDonationModal(false);
          }}
          className="absolute top-5 right-5 w-8 h-8 rounded-full bg-[#18181b] flex items-center justify-center text-[#a1a1aa] hover:text-white"
        >
          <X className="w-4 h-4" />
        </button>

        {!donated ? (
          <div>
            <div className="flex items-center gap-2 mb-2">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#d4af37] to-[#997d1e] flex items-center justify-center text-black shadow-md shadow-[#d4af37]/20">
                <Heart className="w-5 h-5 fill-black" />
              </div>
              <div>
                <h3 className="font-heading font-bold text-white text-lg">Support Edwin's Mission</h3>
                <p className="text-xs text-[#a1a1aa]">Keep inspiration free and accessible worldwide</p>
              </div>
            </div>

            <p className="text-xs text-[#d4d4d8] leading-relaxed my-3 p-3 rounded-2xl bg-[#18181b] border border-[#27272a]">
              Every contribution directly funds the production of free motivational videos, relationship workshops, and community outreach.
            </p>

            <form onSubmit={handleDonate} className="space-y-4">
              {/* Preset Cards */}
              <div className="grid grid-cols-2 gap-2">
                {PRESETS.map((p) => {
                  const isSelected = selectedAmount === p.amount && !customAmount;
                  return (
                    <button
                      type="button"
                      key={p.amount}
                      onClick={() => {
                        setSelectedAmount(p.amount);
                        setCustomAmount('');
                      }}
                      className={`p-3 rounded-2xl border text-left transition-all ${
                        isSelected
                          ? 'bg-[#d4af37]/15 border-[#d4af37] text-white shadow-md shadow-[#d4af37]/15'
                          : 'bg-[#18181b] border-[#27272a] text-[#a1a1aa] hover:border-[#3f3f46]'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm font-bold text-white">${p.amount}</span>
                        {isSelected && <Sparkles className="w-3.5 h-3.5 text-[#d4af37]" />}
                      </div>
                      <p className="text-xs font-semibold text-[#f5e296] leading-tight">{p.label}</p>
                      <p className="text-[10px] text-[#71717a] mt-0.5 leading-snug">{p.desc}</p>
                    </button>
                  );
                })}
              </div>

              {/* Custom Amount */}
              <div>
                <label className="text-xs font-medium text-[#a1a1aa] block mb-1">
                  Or enter custom amount ($ USD)
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-sm font-bold text-[#d4af37]">$</span>
                  <input
                    type="number"
                    min="1"
                    placeholder="Other amount"
                    value={customAmount}
                    onChange={(e) => setCustomAmount(e.target.value)}
                    className="w-full bg-[#18181b] border border-[#27272a] focus:border-[#d4af37] rounded-xl pl-8 pr-3 py-2 text-sm text-white placeholder-[#52525b] focus:outline-none"
                  />
                </div>
              </div>

              {/* Message to Edwin */}
              <div>
                <label className="text-xs font-medium text-[#a1a1aa] block mb-1">
                  Leave a note for Edwin (optional)
                </label>
                <textarea
                  rows={2}
                  placeholder="Thank you Edwin for inspiring my journey..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="w-full bg-[#18181b] border border-[#27272a] focus:border-[#d4af37] rounded-xl px-3 py-2 text-xs text-white placeholder-[#52525b] focus:outline-none"
                />
              </div>

              {/* Action Button */}
              <button
                type="submit"
                disabled={isProcessing}
                className="w-full min-h-[48px] py-3 rounded-xl bg-gradient-to-r from-[#d4af37] via-[#f5e296] to-[#aa820a] text-black font-heading font-bold text-sm flex items-center justify-center gap-2 hover:opacity-95 active:scale-[0.99] transition-all shadow-lg shadow-[#d4af37]/20"
              >
                {isProcessing ? (
                  <div className="w-5 h-5 border-2 border-black border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    <CreditCard className="w-4 h-4" />
                    <span>Contribute ${finalAmount || 0} USD</span>
                  </>
                )}
              </button>

              <div className="flex items-center justify-center gap-1.5 text-[10px] text-[#71717a]">
                <ShieldCheck className="w-3.5 h-3.5 text-[#22c55e]" />
                <span>Secured 256-Bit SSL · Instant Gold Supporter Recognition</span>
              </div>
            </form>
          </div>
        ) : (
          /* Thank You Celebration View */
          <div className="py-6 text-center animate-fadeIn">
            <div className="w-16 h-16 rounded-full bg-[#d4af37]/20 border-2 border-[#d4af37] flex items-center justify-center mx-auto mb-4">
              <Gift className="w-8 h-8 text-[#d4af37]" />
            </div>
            <h3 className="font-heading font-extrabold text-white text-2xl mb-2">
              Heartfelt Thank You!
            </h3>
            <p className="text-sm text-[#f5e296] font-medium mb-3">
              Your contribution of ${finalAmount} has been received.
            </p>
            <p className="text-xs text-[#a1a1aa] leading-relaxed max-w-xs mx-auto mb-6">
              "When one person helps another to stand up, they help humanity move forward." — Edwin
            </p>
            <div className="p-3.5 bg-[#18181b] border border-[#d4af37]/40 rounded-2xl mb-6 text-xs text-[#e4e4e7]">
              <span className="font-bold text-[#d4af37] block mb-1">⭐ VIP Gold Circle Unlocked!</span>
              Enjoy ad-free streaming, priority community replies, and member recognition.
            </div>
            <button
              onClick={() => {
                setDonated(false);
                setShowDonationModal(false);
              }}
              className="w-full py-3 bg-[#18181b] hover:bg-[#27272a] text-white font-semibold rounded-xl text-xs border border-[#27272a] transition-colors"
            >
              Continue to App
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
