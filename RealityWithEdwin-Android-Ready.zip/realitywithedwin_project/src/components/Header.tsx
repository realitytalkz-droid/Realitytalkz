import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Logo } from './Logo';
import { Bell, Crown, Heart, Share2 } from 'lucide-react';
import { NotificationModal } from './NotificationModal';

export const Header: React.FC = () => {
  const { 
    unreadNotifCount, 
    user, 
    setShowDonationModal, 
    openShareModal, 
    toggleVIP 
  } = useApp();

  const [showNotifModal, setShowNotifModal] = useState(false);

  return (
    <>
      <header className="sticky top-0 z-30 h-14 bg-[#09090b]/95 backdrop-blur-md border-b border-[#27272a] px-3.5 flex items-center justify-between shrink-0">
        {/* Left: Brand Identity */}
        <div className="flex items-center">
          <Logo size="sm" showSubtitle={false} />
        </div>

        {/* Right: Actions (Notification Center, VIP status, Share App) */}
        <div className="flex items-center gap-1 sm:gap-2">
          {/* VIP Badge / Upgrade */}
          <button
            onClick={toggleVIP}
            title={user.isVIP ? 'VIP Gold Member' : 'Become a VIP Supporter'}
            className={`min-h-[44px] min-w-[40px] px-2 flex items-center justify-center rounded-xl transition-all ${
              user.isVIP
                ? 'text-[#d4af37] bg-[#d4af37]/15 border border-[#d4af37]/40 font-semibold text-xs'
                : 'text-[#a1a1aa] hover:text-[#f5e296] hover:bg-[#18181b]'
            }`}
          >
            <Crown className={`w-4 h-4 ${user.isVIP ? 'text-[#d4af37] fill-[#d4af37]' : ''}`} />
            {user.isVIP && <span className="ml-1 text-[11px] font-bold text-[#f5e296] hidden xs:inline">VIP</span>}
          </button>

          {/* Quick Support / Donation */}
          <button
            onClick={() => setShowDonationModal(true)}
            title="Support Edwin's Mission"
            className="min-h-[44px] min-w-[40px] px-2 flex items-center justify-center text-[#a1a1aa] hover:text-[#d4af37] hover:bg-[#18181b] rounded-xl transition-colors"
          >
            <Heart className="w-4 h-4" />
          </button>

          {/* Quick Share App */}
          <button
            onClick={() =>
              openShareModal(
                'RealityWithEdwin',
                'Join me on RealityWithEdwin for daily motivational wisdom, relationship advice, and life lessons!',
                window.location.href
              )
            }
            title="Share App"
            className="min-h-[44px] min-w-[40px] px-2 flex items-center justify-center text-[#a1a1aa] hover:text-white hover:bg-[#18181b] rounded-xl transition-colors"
          >
            <Share2 className="w-4 h-4" />
          </button>

          {/* Notification Bell */}
          <button
            onClick={() => setShowNotifModal(true)}
            title="Notifications"
            className="relative min-h-[44px] min-w-[44px] flex items-center justify-center text-[#e4e4e7] hover:text-white hover:bg-[#18181b] rounded-xl transition-colors"
          >
            <Bell className="w-4 h-4" />
            {unreadNotifCount > 0 && (
              <span className="absolute top-2 right-2 flex items-center justify-center min-w-[16px] h-4 px-1 rounded-full bg-[#d4af37] text-black text-[10px] font-extrabold leading-none animate-pulse">
                {unreadNotifCount}
              </span>
            )}
          </button>
        </div>
      </header>

      {/* Notification Drawer Modal */}
      {showNotifModal && <NotificationModal onClose={() => setShowNotifModal(false)} />}
    </>
  );
};
